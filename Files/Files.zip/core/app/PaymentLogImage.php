<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentLogImage extends Model
{
    protected $table = 'payment_log_images';

    protected $guarded = [''];
}
