
<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="checkout-section ptb-50">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 ">
                            <div class="sidebar-title">
                                <h3>User All Order</h3>
                            </div>
                            <div class="">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Created At</th>
                                            <th>Order Number</th>
                                            <th>Total Price</th>
                                            <th>Shipping Status</th>
                                            <th>Order Status</th>
                                            <th>Payment Method</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="product-title">
                                                        <?php echo e(\Carbon\Carbon::parse($con->created_at)->format('dS M\'y - h:i:s A')); ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="product-title">
                                                        <?php echo e($con->order_number); ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="product-title">
                                                        <?php echo e($basic->symbol); ?><?php echo e($con->total); ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="product-title">
                                                        <?php if($con->shipping_status == 0): ?>
                                                            <span class="label label-danger"><i class="fa fa-times"></i> Not Start</span>
                                                        <?php elseif($con->shipping_status == 1): ?>
                                                            <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                                        <?php elseif($con->shipping_status == 2): ?>
                                                            <span class="label label-danger"><i class="fa fa-times"></i> Cancel</span>
                                                        <?php else: ?>
                                                            <span class="label label-success"><i class="fa fa-check"></i> Confirm</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="product-title">
                                                        <?php if($con->status == 0): ?>
                                                            <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                                        <?php elseif($con->status == 1): ?>
                                                            <span class="label label-success"><i class="fa fa-check"></i> Confirm</span>
                                                        <?php else: ?>
                                                            <span class="label label-danger"><i class="fa fa-times"></i> Cancel</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td><?php echo e(\App\PaymentLog::whereOrder_number($con->order_number)->first()->payment->name); ?></td>
                                                <td>
                                                    <div class="product-title">
                                                        <a href="<?php echo e(route('user-order-view',$con->order_number)); ?>" class="btn btn-primary btn-extra-sm"><i class="fa fa-eye"></i>View Order</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="pagination-bar">
                                    <?php echo $order->links('home.pagination'); ?>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>