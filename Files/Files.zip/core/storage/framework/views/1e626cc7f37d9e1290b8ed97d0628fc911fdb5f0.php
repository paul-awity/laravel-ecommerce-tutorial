
<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->


    <section class="ptb-50 ptb-xs-30 gray-bg">
        <div class="container">
            <div class="row testimonial">
                <div class="col-md-12">
                    <p><?php echo $basic->about; ?></p>
                </div>
                <?php if($ad4 != null): ?>
                    <div class="visible-sm visible-md visible-lg hidden-xs">
                        <?php if($ad4->advert_type == 1): ?>
                            <a href="<?php echo e($ad4->link); ?>"  target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad4->val1); ?>" alt="<?php echo e($ad4->title); ?>"></a>
                        <?php else: ?>
                            <?php echo $ad4->val2; ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if($testimonial_hide == 0): ?>

    <section class="ptb-50 ptb-xs-30">
        <div class="container">
            <div class="row testimonial">
                <div id="testimonial_slider" class="text-center">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="testimonial_header">
                                    <div>
                                        <img src="<?php echo e(asset('assets/images/testimonial')); ?>/<?php echo e($t->image); ?>" style="width: 95px" class="center-block img-circle">
                                    </div>
                                    <h5><?php echo e($t->name); ?></h5>
                                    <p><?php echo e($t->position); ?></p>
                                </div>
                                <p><?php echo e($t->message); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>