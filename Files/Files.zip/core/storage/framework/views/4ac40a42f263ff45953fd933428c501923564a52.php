
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="checkout-section ptb-50">
        <div class="container">
            <div class="row">


                <div class="col-md-3 col-sm-4">
                    <div class="account-sidebar account-tab mb-xs-30">
                        <div class="dark-bg tab-title-bg">
                            <div class="heading-part">
                                <div class="sub-title"><span></span> My Account</div>
                            </div>
                        </div>
                        <div class="account-tab-inner">
                            <ul class="account-tab-stap">
                                <li id="step1" class="active"> <a href="javascript:void(0)">My Dashboard<i class="fa fa-angle-right"></i> </a> </li>
                                <li id="step2"> <a href="javascript:void(0)">Account Details<i class="fa fa-angle-right"></i> </a> </li>
                                <li id="step3"> <a href="javascript:void(0)">My Order List<i class="fa fa-angle-right"></i> </a> </li>
                                <li id="step4"> <a href="javascript:void(0)">My Wish List<i class="fa fa-angle-right"></i> </a> </li>
                                <li id="step7"> <a href="javascript:void(0)">My Testimonial<i class="fa fa-angle-right"></i> </a> </li>
                                <li id="step5"> <a href="javascript:void(0)">Change Password<i class="fa fa-angle-right"></i> </a> </li>
                                <li id="step6"> <a href="javascript:void(0)">Get Logout<i class="fa fa-angle-right"></i> </a> </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="col-md-9 col-sm-8">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $error; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div id="data-step1" class="account-content" data-temp="tabdata">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">Account Dashboard</h2>
                                </div>
                            </div>
                        </div>
                        <div class="m-0">
                            <div class="row">
                                <div class="col-xs-12 mb-20">
                                    <div class="heading-part">
                                        <h3 class="sub-heading">Hello, <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h3>
                                    </div>
                                    <hr>
                                </div>

                                <div class="col-sm-6">
                                    <div class="cart-total-table address-box commun-table">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th>Shipping Address</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <?php if(count($userDetails) != 0): ?>
                                                    <td>
                                                        <ul>
                                                            <li class="inner-heading"> <b><?php echo e($userDetails->s_name); ?></b> </li>
                                                            <li>
                                                                <p><?php echo e($userDetails->s_landmark); ?>,<?php echo e($userDetails->s_address); ?></p>
                                                            </li>
                                                            <li>
                                                                <p><?php echo e($userDetails->s_city); ?>,<?php echo e($userDetails->s_state); ?>,<?php echo e($userDetails->s_zip); ?>.</p>
                                                            </li>
                                                            <li>
                                                                <p><?php echo e($userDetails->s_country); ?></p>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                    <?php else: ?>
                                                        <td class="text-center inner-heading"><strong>Not Set Yet</strong> </td>
                                                    <?php endif; ?>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="cart-total-table address-box commun-table">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th>Billing Address</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <?php if(count($userDetails) != 0): ?>
                                                        <td>
                                                            <ul>
                                                                <li class="inner-heading"> <b><?php echo e($userDetails->b_name); ?></b> </li>
                                                                <li>
                                                                    <p><?php echo e($userDetails->b_email); ?>, <?php echo e($userDetails->b_number); ?></p>
                                                                </li>
                                                                <li>
                                                                    <p><?php echo e($userDetails->b_city); ?>,<?php echo e($userDetails->b_state); ?>,<?php echo e($userDetails->b_zip); ?>.</p>
                                                                </li>
                                                                <li>
                                                                    <p><?php echo e($userDetails->b_country); ?></p>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    <?php else: ?>
                                                        <td class="text-center inner-heading"><strong>Not Set Yet</strong> </td>
                                                    <?php endif; ?>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="data-step2" class="account-content" data-temp="tabdata" style="display:none">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">Account Details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="m-0">
                            <form action="<?php echo e(route('user-dashboard-details')); ?>" class="main-form full" method="post">
                                <?php echo csrf_field(); ?>

                                <?php if($userDetails== null): ?>
                                    <div class="mb-20">
                                        <div class="row">
                                            <div class="col-xs-12 mb-20">
                                                <div class="heading-part">
                                                    <h3 class="sidebar-title">Shipping Address</h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="email" name="s_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_company" required placeholder="Company">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_number" required placeholder="Contact Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <select name="s_country" id="shippingcountryid">
                                                        <option selected="" value="">Select Country</option>
                                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_state" required placeholder="State Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_city" required placeholder="City Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_zip" required placeholder="Postcode/zip">
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="input-box">
                                                    <textarea name="s_address" required placeholder="Shipping Address"></textarea>
                                                    <span>Please provide the number and street.</span> </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="input-box">
                                                    <input type="text" name="s_landmark" required placeholder="Shipping Landmark">
                                                    <span>Please include landmark (e.g : Opposite Bank) as the carrier service may find it easier to locate your address.</span> </div>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="row">
                                            <div class="col-xs-12 mb-20">
                                                <div class="heading-part">
                                                    <h3 class="sub-heading">Billing Address</h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_company" required placeholder="Company">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_number" required placeholder="Contact Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <select name="b_country" id="shippingcountryid">
                                                        <option selected="" value="">Select Country</option>
                                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_state" required placeholder="State Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_city" required placeholder="City Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_zip" required placeholder="Postcode/zip">
                                                </div>
                                            </div>
                                            <div class="col-sm-12"> <button type="submit" class="btn btn-color btn-block right-side">Next</button> </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="mb-20">
                                        <div class="row">
                                            <div class="col-xs-12 mb-20">
                                                <div class="heading-part">
                                                    <h3 class="sidebar-title">Shipping Address</h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="email" name="s_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_company" value="<?php echo e($userDetails->s_company); ?>" required placeholder="Company">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_number" value="<?php echo e($userDetails->s_number); ?>" required placeholder="Contact Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <select name="s_country" id="shippingcountryid">
                                                        <option selected="" value="">Select Country</option>
                                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($userDetails->s_country == $value): ?>
                                                                <option value="<?php echo e($value); ?>" selected><?php echo e($value); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_state" value="<?php echo e($userDetails->s_state); ?>" required placeholder="State Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_city" value="<?php echo e($userDetails->s_city); ?>" required placeholder="City Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_zip" value="<?php echo e($userDetails->s_zip); ?>" required placeholder="Postcode/zip">
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="input-box">
                                                    <textarea name="s_address" required placeholder="Shipping Address"><?php echo e($userDetails->s_address); ?></textarea>
                                                    <span>Please provide the number and street.</span> </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="input-box">
                                                    <input type="text" name="s_landmark" value="<?php echo e($userDetails->s_landmark); ?>" required placeholder="Shipping Landmark">
                                                    <span>Please include landmark (e.g : Opposite Bank) as the carrier service may find it easier to locate your address.</span> </div>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="row">
                                            <div class="col-xs-12 mb-20">
                                                <div class="heading-part">
                                                    <h3 class="sub-heading">Billing Address</h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_company" value="<?php echo e($userDetails->b_company); ?>" required placeholder="Company">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_number" value="<?php echo e($userDetails->b_number); ?>" required placeholder="Contact Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <select name="b_country" id="shippingcountryid">
                                                        <option selected="" value="">Select Country</option>
                                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($userDetails->b_country == $value): ?>
                                                                <option value="<?php echo e($value); ?>" selected><?php echo e($value); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_state" value="<?php echo e($userDetails->b_state); ?>" required placeholder="State Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_city" value="<?php echo e($userDetails->b_city); ?>" required placeholder="City Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_zip" value="<?php echo e($userDetails->b_zip); ?>" required placeholder="Postcode/zip">
                                                </div>
                                            </div>
                                            <div class="col-sm-12"> <button type="submit" class="btn btn-color btn-block right-side">Update Address</button> </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                    <div id="data-step3" class="account-content" data-temp="tabdata" style="display:none">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">My Orders</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 mb-xs-30">
                                <div class="">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Created At</th>
                                                <th>Order Number</th>
                                                <th>Total Price</th>
                                                <th>Shipping Status</th>
                                                <th>Order Status</th>
                                                <th>Payment Method</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="product-title">
                                                            <?php echo e(\Carbon\Carbon::parse($con->created_at)->format('dS M\'y - h:i:s A')); ?>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="product-title">
                                                            <?php echo e($con->order_number); ?>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="product-title">
                                                            <?php echo e($basic->symbol); ?><?php echo e($con->total); ?>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="product-title">
                                                            <?php if($con->shipping_status == 0): ?>
                                                                <span class="label label-danger"><i class="fa fa-times"></i> Not Start</span>
                                                            <?php elseif($con->shipping_status == 1): ?>
                                                                <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                                            <?php elseif($con->shipping_status == 2): ?>
                                                                <span class="label label-danger"><i class="fa fa-times"></i> Cancel</span>
                                                            <?php else: ?>
                                                                <span class="label label-success"><i class="fa fa-check"></i> Confirm</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="product-title">
                                                            <?php if($con->status == 0): ?>
                                                                <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                                            <?php elseif($con->status == 1): ?>
                                                                <span class="label label-success"><i class="fa fa-check"></i> Confirm</span>
                                                            <?php else: ?>
                                                                <span class="label label-danger"><i class="fa fa-times"></i> Cancel</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e(\App\PaymentLog::whereOrder_number($con->order_number)->first()->payment->name); ?></td>
                                                    <td>
                                                        <div class="product-title">
                                                            <a href="<?php echo e(route('user-order-view',$con->order_number)); ?>" class="btn btn-primary btn-extra-sm"><i class="fa fa-eye"></i>View</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="pagination-bar">
                                        <?php echo $order->links('home.pagination'); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="data-step4" class="account-content" data-temp="tabdata" style="display:none">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">My Wish List</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 mb-xs-30">
                                <div class="">
                                    <div class="cart-item-table commun-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                <tr>
                                                    <th>Product Image</th>
                                                    <th>Product Name</th>
                                                    <th>Price</th>
                                                    <th>Quantity</th>
                                                    <th>Add Cart</th>
                                                    <th>Action</th>
                                                </tr>
                                                </thead>
                                                <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <a href="<?php echo e(route('product-details',$con->product->slug)); ?>">
                                                                <div class="product-image1"><img alt="<?php echo e($con->product->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($con->product->image); ?>"></div>
                                                            </a>
                                                        </td>
                                                        <td>
                                                            <div class="product-title1">
                                                                <a href="<?php echo e(route('product-details',$con->product->slug)); ?>"><?php echo e($con->product->name); ?></a>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <ul>
                                                                <li>
                                                                    <div class="base-price price-box1"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e($con->product->current_price); ?></span> </div>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                        <td>
                                                            <div class="input-box">
                                                                <div class="custom-qty">
                                                                    <button onclick="var result = document.getElementById('qty<?php echo e($con->id); ?>'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button"> <i class="fa fa-minus"></i> </button>
                                                                    <input type="text" class="input-text qty" readonly title="Qty" value="1" maxlength="<?php echo e($con->product->stock); ?>" id="qty<?php echo e($con->id); ?>" name="qty">
                                                                    <button onclick="var result = document.getElementById('qty<?php echo e($con->id); ?>'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button"> <i class="fa fa-plus"></i> </button>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <button data-id="<?php echo e($con->product_id); ?>" id="wish<?php echo e($con->id); ?>" class="btn btn-color"><i class="fa fa-cart-plus"></i></button>
                                                        </td>
                                                        <td>
                                                            <button type="button" class="btn btn-danger delete_button"
                                                                    data-toggle="modal" data-target="#DelModal"
                                                                    data-id="<?php echo e($con->id); ?>">
                                                                <i class='fa fa-trash'></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="data-step5" class="account-content" data-temp="tabdata" style="display:none">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">Change Password</h2>
                                </div>
                            </div>
                        </div>
                        <form class="main-form full" action="<?php echo e(route('user-update-password')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="input-box">
                                        <label for="old-pass">Old-Password</label>
                                        <input type="password" name="old_password" placeholder="Old Password" required id="old-pass">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input-box">
                                        <label for="login-pass">Password</label>
                                        <input type="password" name="password" placeholder="Enter your Password" required id="login-pass">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="input-box">
                                        <label for="re-enter-pass">Re-enter Password</label>
                                        <input type="password" name="password_confirmation" placeholder="Re-enter your Password" required id="re-enter-pass">
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <button class="btn btn-block btn-color" type="submit" name="submit">Change Password</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div id="data-step6" class="account-content" data-temp="tabdata" style="display:none">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">Get Logout</h2>
                                </div>
                            </div>
                        </div>

                        <a href="<?php echo e(route('logout')); ?>" class="btn btn-block btn-color" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> Logout</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                    <div id="data-step7" class="account-content" data-temp="tabdata" style="display:none">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h2 class="heading m-0">My Testimonial</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part heading-bg mb-30">
                                    <h3 class="heading m-0">Testimonial Status :
                                        <?php if($testimonial == null): ?>
                                        <span class="label label-primary"><i class="fa fa-times"></i> Not Submitted</span>
                                        <?php else: ?>
                                            <?php if($testimonial->status == 0): ?>
                                                <span class="label label-primary"><i class="fa fa-spinner"></i> Pending</span>
                                            <?php else: ?>
                                                <span class="label label-success"><i class="fa fa-check"></i> Approved</span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </h3>
                                </div>
                            </div>
                        </div>
                        <?php if($testimonial == null): ?>
                            <form class="main-form full" action="<?php echo e(route('user-send-testimonial')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="old-pass">Author Name</label>
                                            <input type="text" name="name" placeholder="Author name" required id="old-pass">
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="login-pass">Author Position</label>
                                            <input type="text" name="position" placeholder="Author Position" required id="login-pass">
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="re-enter-pass">Author Image</label>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                                        <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                                            <img style="width: 200px" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=Author Image" alt="...">
                                                        </div>
                                                        <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                                        <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="image" accept="image/*">
                                                </span>
                                                            <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="login-pass">Testimonial Text</label>
                                            <textarea name="message" placeholder="Testimonial Text" rows="4" required id="login-pass"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <button class="btn btn-block btn-color" type="submit" name="submit">Submit Testimonial</button>
                                    </div>
                                </div>
                            </form>
                        <?php else: ?>
                            <form class="main-form full" action="<?php echo e(route('user-update-testimonial')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="old-pass">Author Name</label>
                                            <input type="text" name="name" placeholder="Author name" value="<?php echo e($testimonial->name); ?>" required id="old-pass">
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="login-pass">Author Position</label>
                                            <input type="text" name="position" placeholder="Author Position" value="<?php echo e($testimonial->position); ?>" required id="login-pass">
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="re-enter-pass">Author Image</label>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                                        <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                                            <img style="width: 200px" src="<?php echo e(asset('assets/images/testimonial')); ?>/<?php echo e($testimonial->image); ?>" alt="...">
                                                        </div>
                                                        <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                                        <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="image" accept="image/*">
                                                </span>
                                                            <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-box">
                                            <label for="login-pass">Testimonial Text</label>
                                            <textarea name="message" placeholder="Testimonial Text" rows="4" required id="login-pass"><?php echo e($testimonial->message); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <button class="btn btn-block btn-color" type="submit" name="submit">Update Testimonial</button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->
    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> <strong>Confirmation !</strong></h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete ?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('wishlist-delete')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <input type="hidden" name="id" class="delete_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> DELETE</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".delete_id").val(id);
            });
        });
    </script>

    <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <script>
            var url = '<?php echo e(url('/')); ?>';
            $(document).ready(function () {
                $(document).on("click", '#wish<?php echo e($con->id); ?>', function (e) {

                    $.post(
                        '<?php echo e(url('/wishlist-to-cart')); ?>',
                        {
                            _token: '<?php echo e(csrf_token()); ?>',
                            id : $(this).data('id'),
                            qty : $('#qty<?php echo e($con->id); ?>').val()
                        },
                        function(data) {
                            var result = $.parseJSON(data);
                            if (result['cartError'] == "yes"){
                                toastr.warning(result['cartErrorMessage']);
                            }else{
                                toastr.success('Cart Updated Successfully.');
                                $('#cartShow').empty();
                                $('#cartShow').append(result['cartShowFinal']);
                                $('#cartFullView').empty();
                                var div = document.getElementById('cartFullView');
                                div.innerHTML = result['all'];
                            }
                        }
                    );
                });
            });
        </script>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>