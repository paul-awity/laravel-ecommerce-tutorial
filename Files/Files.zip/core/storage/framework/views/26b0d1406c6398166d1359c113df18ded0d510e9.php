
<?php $__env->startSection('content'); ?>

    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->
    <section class="ptb-50 ptb-xs-30">
        <div class="container">
            <div class="row testimonial">
                <div class="col-md-12">
                    <?php if($compare == null): ?>
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="text-center" style="font-size: 24px;font-weight: bold;">No Product to Compare List..!</h2>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="cart-item-table commun-table mb-30">
                        <div class="table table-responsive text-center">
                            <table class="table-bordered">
                                <?php if($status == 1): ?>
                                    <thead>
                                    <tr>
                                        <th>Description</th>
                                        <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>Product <?php echo e(++$key); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Image</td>
                                        <td>
                                            <a href="<?php echo e(route('product-details',$product1->slug)); ?>">
                                                <div class="product-image"><img alt="<?php echo e($product1->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product1->image); ?>"></div>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td>
                                            <div class="product-title">
                                                <a href="<?php echo e(route('product-details',$product1->slug)); ?>"><?php echo e($product1->name); ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Price</td>
                                        <td>
                                            <div class="product-title">
                                                <?php echo e($basic->symbol); ?><?php echo e($product1->current_price); ?>

                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Color</td>
                                        <td>
                                            <?php if($product1->color_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product1->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Size</td>
                                        <td>
                                            <?php if($product1->size_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product1->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Cart</td>
                                        <td>
                                            <a data-id="<?php echo e($product1->id); ?>" class="btn btn-primary btn-sm SingleCartAdd"><i class="fa fa-shopping-cart"></i> Add To Cart</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Action</td>
                                        <td>
                                            <a id="removeCompare" data-id="<?php echo e($product1->id); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Remove Compare</a>
                                        </td>
                                    </tr>
                                    </tbody>

                                <?php elseif($status == 2): ?>
                                    <thead>
                                    <tr>
                                        <th>Description</th>
                                        <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>Product <?php echo e(++$key); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Image</td>
                                        <td>
                                            <a href="<?php echo e(route('product-details',$product1->slug)); ?>">
                                                <div class="product-image"><img alt="<?php echo e($product1->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product1->image); ?>"></div>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('product-details',$product2->slug)); ?>">
                                                <div class="product-image"><img alt="<?php echo e($product2->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product2->image); ?>"></div>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td>
                                            <div class="product-title">
                                                <a href="<?php echo e(route('product-details',$product1->slug)); ?>"><?php echo e($product1->name); ?></a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-title">
                                                <a href="<?php echo e(route('product-details',$product2->slug)); ?>"><?php echo e($product2->name); ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Price</td>
                                        <td>
                                            <div class="product-title">
                                                <?php echo e($basic->symbol); ?><?php echo e($product1->current_price); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-title">
                                                <?php echo e($basic->symbol); ?><?php echo e($product2->current_price); ?>

                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Color</td>
                                        <td>
                                            <?php if($product1->color_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product1->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product2->color_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product2->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Size</td>
                                        <td>
                                            <?php if($product1->size_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product1->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product2->size_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product2->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Cart</td>
                                        <td>
                                            <a data-id="<?php echo e($product1->id); ?>" class="btn btn-primary btn-sm SingleCartAdd"><i class="fa fa-shopping-cart"></i> Add To Cart</a>
                                        </td>
                                        <td>
                                            <a data-id="<?php echo e($product2->id); ?>" class="btn btn-primary btn-sm SingleCartAdd"><i class="fa fa-shopping-cart"></i> Add To Cart</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Action</td>
                                        <td>
                                            <a id="removeCompare" data-id="<?php echo e($product1->id); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Remove Compare</a>
                                        </td>
                                        <td>
                                            <a id="removeCompare" data-id="<?php echo e($product2->id); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Remove Compare</a>
                                        </td>
                                    </tr>
                                    </tbody>
                                <?php else: ?>
                                    <thead>
                                    <tr>
                                        <th>Description</th>
                                        <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>Product <?php echo e(++$key); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Image</td>
                                        <td>
                                            <a href="<?php echo e(route('product-details',$product1->slug)); ?>">
                                                <div class="product-image"><img alt="<?php echo e($product1->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product1->image); ?>"></div>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('product-details',$product2->slug)); ?>">
                                                <div class="product-image"><img alt="<?php echo e($product2->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product2->image); ?>"></div>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('product-details',$product3->slug)); ?>">
                                                <div class="product-image"><img alt="<?php echo e($product3->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product3->image); ?>"></div>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td>
                                            <div class="product-title">
                                                <a href="<?php echo e(route('product-details',$product1->slug)); ?>"><?php echo e($product1->name); ?></a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-title">
                                                <a href="<?php echo e(route('product-details',$product2->slug)); ?>"><?php echo e($product2->name); ?></a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-title">
                                                <a href="<?php echo e(route('product-details',$product2->slug)); ?>"><?php echo e($product3->name); ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Price</td>
                                        <td>
                                            <div class="product-title">
                                                <?php echo e($basic->symbol); ?><?php echo e($product1->current_price); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-title">
                                                <?php echo e($basic->symbol); ?><?php echo e($product2->current_price); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-title">
                                                <?php echo e($basic->symbol); ?><?php echo e($product3->current_price); ?>

                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Color</td>
                                        <td>
                                            <?php if($product1->color_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product1->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product2->color_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product2->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product3->color_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product3->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Size</td>
                                        <td>
                                            <?php if($product1->size_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product1->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product2->size_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product2->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product3->size_status == 0): ?>
                                                <strong>-</strong>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $product3->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="label label-primary"><?php echo e($c->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Cart</td>
                                        <td>
                                            <a data-id="<?php echo e($product1->id); ?>" class="btn btn-primary btn-sm SingleCartAdd"><i class="fa fa-shopping-cart"></i> Add To Cart</a>
                                        </td>
                                        <td>
                                            <a data-id="<?php echo e($product2->id); ?>" class="btn btn-primary btn-sm SingleCartAdd"><i class="fa fa-shopping-cart"></i> Add To Cart</a>
                                        </td>
                                        <td>
                                            <a data-id="<?php echo e($product3->id); ?>" class="btn btn-primary btn-sm SingleCartAdd"><i class="fa fa-shopping-cart"></i> Add To Cart</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Action</td>
                                        <td>
                                            <a id="removeCompare" data-id="<?php echo e($product1->id); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Remove Compare</a>
                                        </td>
                                        <td>
                                            <a id="removeCompare" data-id="<?php echo e($product2->id); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Remove Compare</a>
                                        </td>
                                        <td>
                                            <a id="removeCompare" data-id="<?php echo e($product3->id); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Remove Compare</a>
                                        </td>
                                    </tr>
                                    </tbody>
                                <?php endif; ?>

                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {
            $(document).on("click", '#removeCompare', function (e) {
                var compareId = $(this).data('id');

                var url = '<?php echo e(url('/')); ?>';

                $.get(url + '/compare-remove/' + compareId,function (data) {

                    var result = $.parseJSON(data);

                    if (result['errorStatus'] == "yes"){
                        toastr.warning(result['errorDetails']);
                    }else{
                        toastr.success(result['errorDetails']);
                        window.location.href = '<?php echo e(url('/compare')); ?>';
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>