<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-primary btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div>
                    <!-- /. tools -->
                </div>
                <!-- /.box-header -->
                <div class="box-body pad">


                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-area-chart"></i> Your Statistic</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="row">
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-purple-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($balance); ?><span><?php echo e($basic->symbol); ?></span></h3>
                                            <p>Your Balance</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-diamond"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-aqua-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalProduct); ?><span></span></h3>
                                            <p>Total Product</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-list"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-yellow-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalPending); ?><span></span></h3>
                                            <p>Pending Product</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-spinner"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-blue-gradient">
                                        <div class="inner">
                                            <h3><span class="counter"><?php echo e($totalConfirm); ?></span></h3>
                                            <p>Confirm Product</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                            </div>
                        </div>
                    </div>
                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-pie-chart"></i> Your Statistic</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="row">
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <a href="<?php echo e(route('provider-add-product')); ?>">
                                    <div class="small-box bg-purple-gradient">
                                        <div class="inner">
                                            <h3>Add Product</h3>
                                            <p><?php echo e($site_title); ?></p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-plus"></i>
                                        </div>
                                    </div>
                                    </a>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <a href="<?php echo e(route('provider-all-product')); ?>">
                                    <div class="small-box bg-aqua-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalProduct); ?><span>+</span></h3>
                                            <p>All Product</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-desktop"></i>
                                        </div>
                                    </div>
                                    </a>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <a href="<?php echo e(route('provider-edit-profile')); ?>">
                                    <div class="small-box bg-light-blue-gradient">
                                        <div class="inner">
                                            <h3>Edit Profile</h3>
                                            <p>Update Profile</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-edit"></i>
                                        </div>
                                    </div>
                                    </a>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <a href="<?php echo e(route('provider.logout')); ?>">
                                    <div class="small-box bg-red-gradient">
                                        <div class="inner">
                                            <h3>Log Out</h3>
                                            <p>Return LogIn</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-sign-out"></i>
                                        </div>
                                    </div>
                                    </a>
                                </div>
                                <!-- ./col -->
                            </div>
                        </div>
                    </div>


                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-cloud-download"></i> Withdraw Statistic</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="row">
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-purple-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalWithdraw); ?><span><?php echo e($basic->symbol); ?></span></h3>
                                            <p>Total Withdraw</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-cloud-download"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-yellow-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalPending); ?><span><?php echo e($basic->symbol); ?></span></h3>
                                            <p>Withdraw Pending</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-spinner"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-purple-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalWithdraw); ?><span><?php echo e($basic->symbol); ?></span></h3>
                                            <p>Withdraw Confirm</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-check"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                                <div class="col-lg-3 col-xs-6">
                                    <!-- small box -->
                                    <div class="small-box bg-red-gradient">
                                        <div class="inner">
                                            <h3><?php echo e($totalRefund); ?><span><?php echo e($basic->symbol); ?></span></h3>
                                            <p>Withdraw Refund</p>
                                        </div>
                                        <div class="icon">
                                            <i class="fa fa-times"></i>
                                        </div>
                                    </div>
                                </div>
                                <!-- ./col -->
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.provider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>