<!DOCTYPE html>
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <?php if($meta_status == 1 ): ?>
        <meta name="keywords" content="<?php echo e($basic->meta_tag); ?>">
        <meta name="description" content="<?php echo e($basic->title); ?>">
        <meta property="og:title" content="<?php echo e($basic->title); ?>" />
        <meta property="og:url" content="<?php echo e(url('/')); ?>" />
        <meta property="og:image" content="<?php echo e(asset('assets/images/logo.png')); ?>" />
    <?php else: ?>
        <?php echo $__env->yieldContent('meta'); ?>
    <?php endif; ?>
    <title><?php echo e($site_title); ?> | <?php echo e($page_title); ?></title>

    <!-- Mobile Specific Metas
      ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSS
      ================================================== -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/fotorama.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/toastr.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/color.php')); ?>?color=<?php echo e($basic->color); ?>">
    <?php echo $__env->yieldContent('style'); ?>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
</head>
<body>
<div class="se-pre-con"></div>

<div class="main">
    <!-- HEADER START -->
    <header class="navbar navbar-custom" id="header">
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-6 p-0">
                        <div class="footer_social pt-xs-15 center-xs mt-xs-15">
                            <ul class="social-icon">
                                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e($sc->link); ?>" class="facebook"><?php echo $sc->code; ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-6">
                        <div class="top-link right-side">
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('compare')); ?>" title="Wishlish">
                                        <i class="fa fa-heart hidden-sm hidden-lg" aria-hidden="true"></i>
                                        <span class="">Compare</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('wishlist')); ?>" title="Wishlish">
                                        <i class="fa fa-heart hidden-sm hidden-lg" aria-hidden="true"></i>
                                        <span class="">Wishlist</span>
                                    </a>
                                </li>

                                <?php if(Auth::check()): ?>
                                    <li>
                                        <div class="btn-group show-on-hover">
                                        <span class="btn btn-default dropdown-toggle" data-toggle="dropdown" style="padding: 1px 10px">
                                            &nbsp;Hi.<?php echo e(Auth::user()->first_name); ?> <span class="caret"></span>
                                        </span>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="<?php echo e(route('user-dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                                                <li><a href="<?php echo e(route('user-all-order')); ?>"><i class="fa fa-shopping-cart"></i> All Order</a></li>
                                                <li><a href="<?php echo e(route('user-edit-profile')); ?>"><i class="fa fa-edit"></i> Edit Profile</a></li>
                                                <li><a href="<?php echo e(route('user-change-password')); ?>"><i class="fa fa-send"></i> Update Password</a></li>
                                                <li class="divider"></li>
                                                <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> Logout</a></li>
                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                    <?php echo e(csrf_field()); ?>

                                                </form>
                                            </ul>
                                        </div>
                                    </li>
                                <?php else: ?>
                                <li>
                                    <a href="<?php echo e(route('login')); ?>" title="Login">
                                        <i class="fa fa-lock hidden-sm hidden-lg" aria-hidden="true"></i>
                                        <span class="hidden-xs">Login</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-middle">
            <div class="container">
                <hr>
                <div class="header-inner">
                    <div class="row">
                        <div class="col-md-7 col-sm-6 col-xs-6">
                            <div class="navbar-header">
                                <a class="navbar-brand page-scroll" href="<?php echo e(route('home')); ?>"> <img alt="<?php echo e($basic->title); ?>" src="<?php echo e(asset('assets/images/logo.png')); ?>"> </a>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-6 col-xs-6">
                            <div class="right-side">
                                <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"><i class="fa fa-bars"></i></button>
                                <div class="right-side float-left-xs header-right-link">
                                    <div class="main-search">
                                        <div class="header_search_toggle desktop-view">
                                            <form action="<?php echo e(route('search-product')); ?>" method="get" >
                                                <div class="search-box">
                                                    <input class="input-text" type="text" name="name" placeholder="Search entire store here...">
                                                    <button class="search-btn"></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="header_search_toggle mobile-view">

                                <form action="<?php echo e(route('search-product')); ?>" method="get" >
                                    <div class="search-box">
                                        <input class="input-text" name="name" type="text" placeholder="Search entire store here...">
                                        <button class="search-btn"></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="header-bottom">
                <div class="">
                    <div id="menu" class="navbar-collapse collapse left-side p-0">
                        <ul class="nav navbar-nav navbar-left">
                            <li class="level"><a href="<?php echo e(route('home')); ?>" class="page-scroll">Home</a></li>
                            <?php $__currentLoopData = $menubarCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="level">
                                <span class="opener plus"></span>
                                <a href="<?php echo e(route('category',['id'=>$mcat->id,'slug'=>str_slug($mcat->name)])); ?>" class="page-scroll"><?php echo e($mcat->name); ?></a>
                                <div class="megamenu full mobile-sub-menu">
                                    <div class="megamenu-inner">
                                        <div class="megamenu-inner-top">
                                            <div class="row">
                                                <?php $mSubCat = \App\Subcategory::whereCategory_id($mcat->id)->get() ?>
                                                <?php $__currentLoopData = $mSubCat->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkSubcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $chunkSubcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-3 level2">
                                                            <a href="<?php echo e(route('subcategory',['id'=>$cc->id,'slug'=>str_slug($cc->name)])); ?>"><span><?php echo e($cc->name); ?></span></a>
                                                            <ul class="sub-menu-level2 ">
                                                                <?php $menuChildCat = \App\ChildCategory::wheresubcategory_id($cc->id)->get() ?>
                                                                <?php $__currentLoopData = $menuChildCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mChildCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li class="level3"><a href="<?php echo e(route('childcategory',['id'=>$mChildCat->id,'slug'=>str_slug($mChildCat->name)])); ?>"><?php echo e($mChildCat->name); ?></a></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li class="level"><a href="<?php echo e(route('contact-us')); ?>" class="page-scroll">Contact Us</a></li>
                        </ul>
                        <div class="header_search_toggle mobile-view">
                            <form>
                                <div class="search-box">
                                    <input class="input-text" type="text" placeholder="Search entire store here...">
                                    <button class="search-btn"></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="right-side float-left-xs header-right-link">
                        <ul id="cartShow">
                            <li class="cart-icon">
                                <a href="#">
                                    <span> <small class="cart-notification"><?php echo e(Cart::count()); ?></small> </span>
                                    <div class="cart-text hidden-sm hidden-xs">My Cart</div>
                                </a>
                                <div class="cart-dropdown header-link-dropdown">
                                    <ul class="cart-list link-dropdown-list">
                                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a data-id="<?php echo e($cont->rowId); ?>" class="close-cart delete_cart"><i class="fa fa-times-circle"></i></a>
                                            <div class="media">
                                                <a class="pull-left"> <img alt="<?php echo e($cont->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($cont->options->image); ?>"></a>
                                                <div class="media-body"> <span><a><?php echo e(substr($cont->name,0,25)); ?>..</a></span>
                                                    <p class="cart-price"><?php echo e($basic->symbol); ?><?php echo e($cont->price); ?> x <?php echo e($cont->qty); ?></p>
                                                </div>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <p class="cart-sub-totle"> <span class="pull-left">Cart Subtotal</span> <span class="pull-right"><strong class="price-box"><?php echo e($basic->symbol); ?><?php echo e(Cart::subtotal()); ?></strong></span> </p>
                                    <div class="clearfix"></div>
                                    <div class="mt-20"> <a href="<?php echo e(route('cart')); ?>" class="btn-color btn">Cart</a> <a href="<?php echo e(route('check-out')); ?>" class="btn-color btn right-side">Checkout</a> </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="menu-shadow-btm"><img src="<?php echo e(asset('assets/images/menu-shadow.png')); ?>" alt="MarketShop"></div>
            </div>
        </div>
    </header>
    <!-- HEADER END -->

    <?php echo $__env->yieldContent('content'); ?>


<!-- Brand logo block Start  -->
    <section class="dark-bg">
        <div class="container">
            <div class="row brand ptb-50">
                <div class="col-md-12">
                    <div id="brand-logo" class="owl-carousel align_center">
                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=""><a href="<?php echo e(route('partner-product',$p->id)); ?>"><img src="<?php echo e(asset('assets/images/partner')); ?>/<?php echo e($p->image); ?>" alt="<?php echo e($p->name); ?>"/></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row half-row">
            <div class="col-sm-6 half-div color">
                <div class="half-inner">

                    <h3 class="bold uppercase extra-heading">Accepted Payment Method</h3>
                    <p>We Accept Most World Class Payment Method.</p>
                    <div class="partners-carousel alt">
                        <div class="owl-carousel" id="partners-alt">
                            <?php $__currentLoopData = $paymentImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><a><img src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($pt->image); ?>" alt="<?php echo e($pt->name); ?>" width="90%"></a></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div><!-- /.half-div -->

            <div class="col-sm-6 half-div image" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->subscribe_bg); ?>')">
                <div class="half-inner">
                    <div class="form-subscribe-wrapper alt">
                        <h3 style="color: #fff;font-weight: bold;font-size: 22px;margin-bottom: 0px">SUBSCRIBE TO ANY UPDATE</h3>
                        <p>Subscribe to our latest Updates directly in your inbox.</p>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo $error; ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <!-- Subscribe form -->
                        <form action="<?php echo e(route('submit-subscribe')); ?>" method="post" class="form-subscribe alt" id="form-subscribe">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="formSubscribeEmail" class="sr-only">Enter your email address</label>
                                <input type="email"  class="form-control" name="email" id="formSubscribeEmail"
                                       placeholder="Enter your email here" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
                            </div>
                            <button type="submit" class="btn btn-submit">Subscribe Today</button>
                        </form>
                        <!-- Subscribe form -->

                        <p class="form-subscribe-text-sm">* We don’t share any of your information to others</p>

                    </div>

                </div>
            </div><!-- /.half-div -->

        </div>

    </section>
    <!-- Brand logo block End  -->

    <!-- FOOTER START -->
    <div class="footer">
        <div class="container">
            <div class="footer-inner">
                <div class="footer-middle">
                    <div class="row">
                        <div class="col-md-4 f-col">
                            <div class="footer-static-block"> <span class="opener plus"></span>
                                <div class="f-logo"> <a href="<?php echo e(route('home')); ?>" class=""> <img src="<?php echo e(asset('assets/images/footer-logo.png')); ?>" alt="MarketShop"> </a>
                                </div>
                                <div class="footer-block-contant">
                                    <p><?php echo $basic->footer_text; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-8 f-col">
                                    <div class="footer-static-block">
                                        <h3 class="title">Categories</h3>
                                        <div class="footer_nav">
                                            <ul>
                                                <?php $__currentLoopData = $footerCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(route('category',['id'=>$fcat,'slug'=>str_slug($fcat->name)])); ?>"><?php echo e($fcat->name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 f-col">
                                    <div class="footer-static-block"> <span class="opener plus"></span>
                                        <h3 class="title">Contact With Us</h3>
                                        <ul class="footer-block-contant address-footer">
                                            <li class="item"> <i class="fa fa-home"> </i>
                                                <p><?php echo e($basic->address); ?></p>
                                            </li>
                                            <li class="item"> <i class="fa fa-envelope"> </i>
                                                <p> <a><?php echo e($basic->email); ?> </a> </p>
                                            </li>
                                            <li class="item"> <i class="fa fa-phone"> </i>
                                                <p><?php echo e($basic->phone); ?></p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="copy-right center-sm"><?php echo $basic->copy_text; ?></div>
                        </div>
                        <div class="col-sm-8 p-0">
                            <div class="payment float-none-xs center-sm">
                                <ul class="footer-block-contant link">
                                    <li><a href="<?php echo e(route('privacy-policy')); ?>">Privacy Policy</a></li>
                                    <li><a href="<?php echo e(route('terms-condition')); ?>">Terms & Condition</a></li>
                                    <li><a href="<?php echo e(route('about-us')); ?>">About Us</a></li>
                                    <li><a href="<?php echo e(route('contact-us')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="scroll-top">
        <div id="scrollup"></div>
    </div>
    <!-- FOOTER END -->
</div>
<script src="<?php echo e(asset('assets/js/jquery-1.12.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/fotorama.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/toastr.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
    $(document).ready(function () {
        $(document).on("click", '#compareId', function (e) {
            var id = $(this).data('id');
            var url = '<?php echo e(url('/')); ?>';

            $.get(url + '/compare-add/' + id,function (data) {

                var result = $.parseJSON(data);

                if (result['errorStatus'] == "yes"){
                    toastr.warning(result['errorDetails']);
                }else{
                    toastr.success(result['errorDetails']);
                }
            });
        });
    });
</script>
<script>

    $(document).ready(function () {
        $(document).on("click", '.delete_cart', function (e) {
            var rowId = $(this).data('id');
            $.post(
                    '<?php echo e(url('/delete-cart-item')); ?>',
                    {
                        _token: '<?php echo e(csrf_token()); ?>',
                        rowId : rowId
                    },
                    function(data) {
                        var result = $.parseJSON(data);
                        toastr.success('Product Deleted From Cart.');
                        $('#cartShow').empty();
                        $('#cartShow').append(result['cartShow']);
                        $('#cartFullView').empty();
                        var div = document.getElementById('cartFullView');
                        div.innerHTML = result['fullShow'];
                    }

            );
        });
        $(document).on("click", '.SingleCartAdd', function (e) {
            var id = $(this).data('id');
            $.post(
                '<?php echo e(url('/single-cart-add')); ?>',
                {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id : id
                },
                function(data) {
                    toastr.success('Product Added To Cart.');
                    $('#cartShow').empty();
                    $('#cartShow').append(data);
                }
            );
        });
        $(document).on("click", '.SingleWishList', function (e) {
            var id = $(this).data('id');
            $.post(
                    '<?php echo e(url('/single-wishlist-add')); ?>',
                    {
                        _token: '<?php echo e(csrf_token()); ?>',
                        id : id
                    },
                    function(data) {
                        var result = $.parseJSON(data);
                        if (result['cartError'] == "yes"){
                            toastr.warning(result['cartErrorMessage']);
                        }else if(result['cartError'] == "exist"){
                            toastr.info(result['cartErrorMessage']);
                        }else {
                            toastr.success(result['cartErrorMessage']);
                        }
                    }
            );
        });
    });

</script>
<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
        case 'warning':
            toastr.warning("<?php echo e(Session::get('message')); ?>");
            break;
        case 'success':
            toastr.success("<?php echo e(Session::get('message')); ?>");
            break;
        case 'error':
            toastr.error("<?php echo e(Session::get('message')); ?>");
            break;
    }
    <?php endif; ?>
</script>
<?php echo $basic->google_analytic; ?>

<?php echo $basic->chat; ?>



</body>

</html>


