<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="checkout-section ptb-50">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="checkout-step mb-40">
                        <ul>
                            <li> <a href="<?php echo e(route('check-out')); ?>">
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">1</div>
                                    </div>
                                    <span>Shipping</span> </a> </li>
                            <li class="active"> <a href="<?php echo e(route('oder-overview')); ?>">
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">2</div>
                                    </div>
                                    <span>Order Overview</span> </a> </li>
                            <li> <a>
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">3</div>
                                    </div>
                                    <span>Payment</span> </a> </li>
                            <li> <a>
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">4</div>
                                    </div>
                                    <span>Order Complete</span> </a> </li>
                            <li>
                                <div class="step">
                                    <div class="line"></div>
                                </div>
                            </li>
                        </ul>
                        <hr>
                    </div>

                    <div class="checkout-content">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part align-center">
                                    <h2 class="heading">Order Overview</h2>
                                </div>
                            </div>
                        </div>
                        <div id="cartFullView" class="row">
                            <div class="col-xs-12 mb-xs-30">
                                <div class="sidebar-title">
                                    <h3><?php echo e($page_title); ?></h3>
                                </div>
                                <div class="cart-item-table commun-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Product Name</th>
                                                <th>Price</th>
                                                <th>Color</th>
                                                <th>Size</th>
                                                <th>Quantity</th>
                                                <th>Sub Total</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $product = \App\Product::findOrFail($con->id) ?>
                                                <tr id="product_<?php echo e($con->rowId); ?>">
                                                    <td>
                                                        <a href="<?php echo e(route('product-details',$product->slug)); ?>">
                                                            <div class="product-image"><img alt="<?php echo e($con->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($con->options->image); ?>"></div>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <div class="product-title">
                                                            <a href="<?php echo e(route('product-details',$product->slug)); ?>"><?php echo e($con->name); ?></a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <ul>
                                                            <li>
                                                                <div class="base-price price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e($con->price); ?></span> </div>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                    <td>
                                                        <ul>
                                                            <li>
                                                                <?php if($con->options->color == 0): ?>
                                                                    <div class="base-price price-box"> <span class="price">-</span></div>
                                                                <?php else: ?>
                                                                    <div class="base-price price-box"><span class="label label-default"><?php echo e(\App\Color::findOrFail($con->options->color)->name); ?></span></div>
                                                                <?php endif; ?>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                    <td>
                                                        <ul>
                                                            <li>
                                                                <?php if($con->options->size == 0): ?>
                                                                    <div class="base-price price-box"> <span class="price">-</span></div>
                                                                <?php else: ?>
                                                                    <div class="base-price price-box"><span class="label label-default"><?php echo e(\App\Size::findOrFail($con->options->size)->name); ?></span></div>
                                                                <?php endif; ?>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                    <td>
                                                        <div class="input-box">
                                                            <div class="custom-qty">
                                                                <button id="btnMinus<?php echo e($con->rowId); ?>" onclick="var result = document.getElementById('qty<?php echo e($con->id); ?>'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button"> <i class="fa fa-minus"></i> </button>
                                                                <input type="text" class="input-text qty" readonly title="Qty" value="<?php echo e($con->qty); ?>" maxlength="<?php echo e($product->stock); ?>" id="qty<?php echo e($con->id); ?>" name="qty<?php echo e($con->id); ?>">
                                                                <button id="btnPlus<?php echo e($con->rowId); ?>" onclick="var result = document.getElementById('qty<?php echo e($con->id); ?>'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button"> <i class="fa fa-plus"></i> </button>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><div class="total-price price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e($con->price * $con->qty); ?></span> </div></td>
                                                    <td><i title="Remove Item From Cart" data-id="<?php echo e($con->rowId); ?>" class="fa fa-trash delete_cart cart-remove-item"></i></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-8 col-sm-offset-4">
                                <div class="cart-total-table commun-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <tbody>
                                            <tr>
                                                <td>Item(s) Subtotal</td>
                                                <td><div class="price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e(Cart::subtotal()); ?></span> </div></td>
                                            </tr>
                                            <tr>
                                                <td>Tax - <?php echo e($basic->tax); ?>% </td>
                                                <td><div class="price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e(Cart::tax()); ?></span> </div></td>
                                            </tr>
                                            <tr>
                                                <td><b>Amount Payable</b></td>
                                                <td><div class="price-box"> <span class="price"><b><?php echo e($basic->symbol); ?><?php echo e(Cart::total()); ?></b></span> </div></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="cart-total-table address-box commun-table mb-30">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>Shipping Address</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <ul>
                                                        <li class="inner-heading">
                                                            <b><?php echo e($userDetails->s_name); ?></b>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->s_company); ?>, <?php echo e($userDetails->s_number); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->s_email); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->s_landmark); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->s_address); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->s_zip); ?>, <?php echo e($userDetails->s_city); ?>, <?php echo e($userDetails->s_state); ?>, <?php echo e($userDetails->s_country); ?></p>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="cart-total-table address-box commun-table">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>Billing Address</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td style="padding: 13px">
                                                    <ul>
                                                        <li class="inner-heading">
                                                            <b><?php echo e($userDetails->b_name); ?></b>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->b_company); ?>, <?php echo e($userDetails->b_number); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->b_email); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->b_zip); ?>, <?php echo e($userDetails->b_city); ?>, <?php echo e($userDetails->b_state); ?></p>
                                                        </li>
                                                        <li>
                                                            <p><?php echo e($userDetails->b_country); ?></p>
                                                        </li>
                                                    </ul>
                                                    <br>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div><a href="<?php echo e(route('home')); ?>" class="btn btn-block btn-color"><span><i class="fa fa-angle-left"></i></span>Continue Shopping</a> </div>
                            </div>
                            <div class="col-sm-6">
                                <div>
                                    <form action="<?php echo e(route('confirm-order')); ?>" method="post">
                                        <?php echo csrf_field(); ?>

                                        <button class="btn btn-color btn-block"><i class="fa fa-send"></i> Confirm & Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <script>
            var url = '<?php echo e(url('/')); ?>';
            $(document).ready(function () {
                $(document).on("click", '#btnMinus<?php echo e($con->rowId); ?>', function (e) {
                    var qty = $('#qty<?php echo e($con->id); ?>').val();
                    $.get(url + '/update-cart-item/' + '<?php echo e($con->rowId); ?>'+'/'+qty,function (data) {
                        var result = $.parseJSON(data);
                        if (result['cartError'] == "yes"){
                            toastr.warning(result['cartErrorMessage']);
                        }else{
                            toastr.success('Cart Updated Successfully.');
                            $('#cartShow').empty();
                            $('#cartShow').append(result['cartShow']);
                            $('#cartFullView').empty();
                            var div = document.getElementById('cartFullView');
                            div.innerHTML = result['fullShow'];
                        }
                    });
                });
                $(document).on("click", '#btnPlus<?php echo e($con->rowId); ?>', function (e) {
                    var qty = $('#qty<?php echo e($con->id); ?>').val();
                    $.get(url + '/update-cart-item/' + '<?php echo e($con->rowId); ?>'+'/'+qty,function (data) {
                        var result = $.parseJSON(data);
                        if (result['cartError'] == "yes"){
                            toastr.warning(result['cartErrorMessage']);
                        }else{
                            toastr.success('Cart Updated Successfully.');
                            $('#cartShow').empty();
                            $('#cartShow').append(result['cartShow']);
                            $('#cartFullView').empty();
                            var div = document.getElementById('cartFullView');
                            div.innerHTML = result['fullShow'];
                        }
                    });
                });

            });
        </script>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>