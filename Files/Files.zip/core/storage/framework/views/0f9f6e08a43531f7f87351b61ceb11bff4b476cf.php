<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/dataTables.bootstrap.min.css')); ?>">
    <style>
        @media  print {
            table td:last-child {display:none}
            table th:last-child {display:none}
        }
        .select2-selection,.select2-results{
            font-weight: bold !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">

            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-primary btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div>
                    <!-- /. tools -->
                </div>
                <!-- /.box-header -->
                <div class="box-body pad">

                    <table class="table table-bordered table-hover" id="myTable">
                        <thead>
                        <tr>
                            <th>#SL</th>
                            <th>Order Number</th>
                            <th>Created At</th>
                            <th>Total Amount</th>
                            <th>Payment Status</th>
                            <th>Shipping Status</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody id="products-list">
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="product<?php echo e($key); ?>">
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($product->order_number); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($product->created_at)->format('M d, y - h:i:s A')); ?></td>
                                <td><?php echo e($basic->symbol); ?><?php echo e($product->total); ?></td>
                                <td>
                                    <?php if($product->payment_status == 0): ?>
                                        <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                    <?php else: ?>
                                        <span class="label label-success"><i class="fa fa-check"></i> Paid</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($product->shipping_status == 0): ?>
                                        <span class="label label-danger"><i class="fa fa-times"></i> Not Start</span>
                                    <?php elseif($product->shipping_status == 1): ?>
                                        <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                    <?php elseif($product->shipping_status == 2): ?>
                                        <span class="label label-danger"><i class="fa fa-times"></i> Cancel</span>
                                    <?php else: ?>
                                        <span class="label label-success"><i class="fa fa-check"></i> Confirm</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($product->status == 1): ?>
                                        <span class="label label-primary"><i class="fa fa-check"></i> Confirm</span>
                                    <?php elseif($product->status == 0): ?>
                                        <span class="label label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                    <?php else: ?>
                                        <span class="label label-danger"><i class="fa fa-times"></i> Cancel</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('order-view',$product->order_number)); ?>" class="btn btn-sm btn-primary bold uppercase"><i class="fa fa-eye"></i> View Order</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('import_scripts'); ?>

    <script src="<?php echo e(asset('assets/admin/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/dataTables.bootstrap.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(function () {
            $('#myTable').DataTable({
                'paging'      : true,
                'lengthChange': true,
                'searching'   : true,
                'ordering'    : false,
                'info'        : true
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>