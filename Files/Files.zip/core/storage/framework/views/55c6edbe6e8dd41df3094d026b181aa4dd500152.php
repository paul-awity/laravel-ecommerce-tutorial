
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-primary btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div>
                    <!-- /. tools -->
                </div>
                <!-- /.box-header -->
                <div class="box-body pad">


                    <table class="table table-striped table-bordered table-hover" id="myTable">
                        <thead>
                        <tr>
                            <th>#SL</th>
                            <th>Created At</th>
                            <th>Transaction Number</th>
                            <th>Provider Details</th>
                            <th>Transaction Type</th>
                            <th>Transaction Amount</th>
                            <th>Post Amount</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$k); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('dS M, Y')); ?></td>
                                <td><?php echo e($p->custom); ?></td>
                                <td><?php echo e($p->provider->name); ?> <br><?php echo e($p->provider->email); ?> <br><?php echo e($p->provider->country_code); ?><?php echo e($p->provider->phone); ?>

                                </td>
                                <td>
                                    <?php if($p->type == 1): ?>
                                        <span class="label label-primary">
                                                    <i class="fa fa-shopping-cart font-medium-2"></i>
                                                    <span>Product Sell</span>
                                                </span>
                                    <?php elseif($p->type == 3): ?>
                                        <span class="label label-warning">
                                                    <i class="fa fa-cloud-upload font-medium-2"></i>
                                                    <span>Withdraw</span>
                                                </span>
                                    <?php elseif($p->type == 4): ?>
                                        <span class="label label-warning">
                                                    <i class="fa fa-bolt font-medium-2"></i>
                                                    <span>Withdraw Charge</span>
                                                </span>
                                    <?php elseif($p->type == 5): ?>
                                        <span class="label label-danger">
                                                    <i class="fa fa-cloud-download font-medium-2"></i>
                                                    <span>Withdraw Refund</span>
                                                </span>
                                    <?php elseif($p->type == 6): ?>
                                        <span class="label label-danger">
                                                    <i class="fa fa-bolt font-medium-2"></i>
                                                    <span>Withdraw Charge Refund</span>
                                                </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <b><?php echo e($p->balance); ?> <?php echo e($basic->currency); ?></b>
                                </td>
                                <td>
                                    <b><?php echo e($p->post_balance); ?> <?php echo e($basic->currency); ?></b>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                            <div class="pull-right">
                                <?php echo $log->links(); ?>

                            </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>