<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="checkout-section ptb-50">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="checkout-step mb-40">
                        <ul>
                            <li> <a href="<?php echo e(route('check-out')); ?>">
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">1</div>
                                    </div>
                                    <span>Shipping</span> </a> </li>
                            <li> <a href="<?php echo e(route('oder-overview')); ?>">
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">2</div>
                                    </div>
                                    <span>Order Overview</span> </a> </li>
                            <li class="active"> <a>
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">3</div>
                                    </div>
                                    <span>Payment</span> </a> </li>
                            <li> <a>
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">4</div>
                                    </div>
                                    <span>Order Complete</span> </a> </li>
                            <li>
                                <div class="step">
                                    <div class="line"></div>
                                </div>
                            </li>
                        </ul>
                        <hr>
                    </div>
                    <div class="checkout-content">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part align-center">
                                    <h2 class="heading">Payment with : <?php echo e($paymentMethod->name); ?></h2>
                                    <h2 class="heading">Total Amount : <span class="payment-balance"><?php echo e($basic->symbol); ?><?php echo e($payment->usd); ?></span></h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-10 col-md-10 col-sm-10 col-lg-offset-1 col-sm-offset-1 col-md-offset-1">
                                <div class="payment-option-box">
                                    <div class="payment-option-box-inner gray-bg">
                                        <div class="payment-top-box">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-4 mb-20">
                                                    <div class="paypal-box">
                                                        <img src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($payment->payment->image); ?>">
                                                        <a href="<?php echo e(route('payment',$payment->order_number)); ?>" class="btn btn-color btn-block" style="border-radius: 3px;margin-top: 10px">Back To Another Method</a>
                                                    </div>
                                                </div>
                                                <div class="col-md-8 col-sm-8">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered">
                                                            <tbody>
                                                            <tr>
                                                                <td width="50%" class="text-right"><b>Total Amount</b></td>
                                                                <td width="50%"><div class="price-box text-left">
                                                                        <span class="price"><?php echo e($basic->symbol); ?><?php echo e($payment->amount); ?></span>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="50%" class="text-right"><b>Charge - <?php echo e($basic->symbol); ?><?php echo e($payment->payment->fix); ?>+<?php echo e($payment->payment->percent); ?>%</b></td>
                                                                <td width="50%"><div class="price-box text-left">
                                                                        <span class="price"><?php echo e($basic->symbol); ?><?php echo e($payment->charge); ?></span>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="50%" class="text-right"><b>Net Amount</b></td>
                                                                <td width="50%"><div class="price-box text-left">
                                                                        <span class="price"><?php echo e($basic->symbol); ?><?php echo e($payment->net_amount); ?></span>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="50%" class="text-right"><b>Conversion Rate</b></td>
                                                                <td width="50%"><div class="price-box text-left">
                                                                        <span class="price">1 USD = <?php echo e($payment->payment->rate); ?><?php echo e($basic->currency); ?></span>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="50%" class="text-right"><b>Amount In USD</b></td>
                                                                <td width="50%"><div class="price-box text-left">
                                                                        <span class="price"><?php echo e($basic->symbol); ?><?php echo e($payment->usd); ?></span>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php if($payment->payment_id == 1): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <form action="https://secure.paypal.com/uk/cgi-bin/webscr" method="post" name="paypal" id="paypal">
                                                                <input type="hidden" name="cmd" value="_xclick" />
                                                                <input type="hidden" name="business" value="<?php echo e($payment->payment->val1); ?>" />
                                                                <input type="hidden" name="cbt" value="<?php echo e($site_title); ?>" />
                                                                <input type="hidden" name="currency_code" value="USD" />
                                                                <input type="hidden" name="quantity" value="1" />
                                                                <input type="hidden" name="item_name" value="Buy From <?php echo e($site_title); ?>" />

                                                                <!-- Custom value you want to send and process back in the IPN -->
                                                                <input type="hidden" name="custom" value="<?php echo e($payment->order_number); ?>" />
                                                                <input name="amount" type="hidden" value="<?php echo e($payment->usd); ?>">
                                                                <input type="hidden" name="return" value="<?php echo e(route('order-complete',$payment->order_number)); ?>"/>
                                                                <input type="hidden" name="cancel_return" value="<?php echo e(route('payment',$payment->order_number)); ?>" />
                                                                <!-- Where to send the PayPal IPN to. -->
                                                                <input type="hidden" name="notify_url" value="<?php echo e(route('paypal-ipn')); ?>" />

                                                                <button class="btn btn-primary btn-lg text-uppercase btn-block"><i class="fa fa-paypal"></i> Payment Here</button>

                                                            </form>
                                                        </div>
                                                    <?php elseif($payment->payment_id == 2): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <form action="https://perfectmoney.is/api/step1.asp" method="POST" id="myform">
                                                                <input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo e($payment->payment->val1); ?>">
                                                                <input type="hidden" name="PAYEE_NAME" value="<?php echo e($site_title); ?>">
                                                                <input type='hidden' name='PAYMENT_ID' value='<?php echo e($payment->order_number); ?>'>
                                                                <input type="hidden" name="PAYMENT_AMOUNT"  value="<?php echo e($payment->usd); ?>">
                                                                <input type="hidden" name="PAYMENT_UNITS" value="USD">
                                                                <input type="hidden" name="STATUS_URL" value="<?php echo e(route('perfect-ipn')); ?>">
                                                                <input type="hidden" name="PAYMENT_URL" value="<?php echo e(route('order-complete',$payment->order_number)); ?>">
                                                                <input type="hidden" name="PAYMENT_URL_METHOD" value="GET">
                                                                <input type="hidden" name="NOPAYMENT_URL" value="<?php echo e(route('payment',$payment->order_number)); ?>">
                                                                <input type="hidden" name="NOPAYMENT_URL_METHOD" value="GET">
                                                                <input type="hidden" name="SUGGESTED_MEMO" value="<?php echo e($site_title); ?>">
                                                                <input type="hidden" name="BAGGAGE_FIELDS" value="IDENT"><br>
                                                                <button class="btn btn-primary btn-lg text-uppercase btn-block"><i class="fa fa-credit-card-alt"></i>Payment Here</button>

                                                            </form>
                                                        </div>
                                                    <?php elseif($payment->payment_id == 3): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <h4 style="text-align: center;"> SEND EXACTLY <strong><?php echo e($usd); ?> BTC </strong> TO <strong><?php echo e($add); ?></strong><br>
                                                                <?php echo $code; ?> <br>
                                                                <strong>SCAN TO SEND</strong> <br><br>
                                                                <strong style="color: red;">NB: 3 Confirmation required to Credited your Account</strong>
                                                            </h4>
                                                        </div>
                                                    <?php elseif($payment->payment_id == 4): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <form role="form" method="POST" action="<?php echo e(route('stripe-submit')); ?>">
                                                                <?php echo csrf_field(); ?>

                                                                <input type="hidden" name="amount" value="<?php echo e($payment->usd); ?>">
                                                                <input type="hidden" name="custom" value="<?php echo e($payment->order_number); ?>">
                                                                <input type="hidden" name="error_url" value="<?php echo e(route('payment',$payment->order_number)); ?>">
                                                                <input type="hidden" name="success_url" value="<?php echo e(route('order-complete',$payment->order_number)); ?>">
                                                                <div class="row">
                                                                    <div class="col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="cardNumber">CARD NUMBER</label>
                                                                            <div class="input-group">
                                                                                <input type="tel" class="form-control input-lg" name="cardNumber" placeholder="Valid Card Number" autocomplete="off" required autofocus />
                                                                                <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-xs-4 col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="cardExpiry"><span class="hidden-xs">EXP MONTH</span></label>
                                                                            <input type="tel" class="form-control input-lg" name="cardExpiryMonth" placeholder="MM" autocomplete="off" required />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xs-4 col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="cardExpiry"><span class="hidden-xs">EXP YEAR</span></label>
                                                                            <input type="tel" class="form-control input-lg" name="cardExpiryYear" placeholder="YYYY" autocomplete="off" required />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xs-4 col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="cardCVC">CV CODE</label>
                                                                            <input type="tel" class="form-control input-lg" name="cardCVC" placeholder="CVC" autocomplete="off" required/>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-xs-12">
                                                                        <button class="subscribe btn btn-primary btn-lg text-uppercase btn-block" type="submit"><i class="fa fa-credit-card"></i> Payment Here</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    <?php elseif($payment->payment_id == 5): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <form action="https://www.moneybookers.com/app/payment.pl" method="post">
                                                                <input type="hidden" name="pay_to_email" value="<?php echo e($payment->payment->val1); ?>"/>
                                                                <input type="hidden" name="status_url" value="<?php echo e(route('skrill-ipn')); ?>"/>
                                                                <input type="hidden" name="language" value="EN"/>
                                                                <input name="transaction_id" type="hidden" value="<?php echo e($payment->order_number); ?>">
                                                                <input type="hidden" name="amount" value="<?php echo e($payment->usd); ?>"/>
                                                                <input type="hidden" name="currency" value="USD"/>
                                                                <input type="hidden" name="detail1_description" value="<?php echo e($site_title); ?>"/>
                                                                <input type="hidden" name="detail1_text" value="Charge For - <?php echo e($site_title); ?>"/>
                                                                <input type="hidden" name="logo_url" value="<?php echo e(asset('assets/images/logo.png')); ?>"/>
                                                                <button type="submit" class="btn btn-primary btn-lg text-uppercase btn-block"><i class="fa fa-credit-card"></i>Payment Here</button>
                                                            </form>
                                                        </div>
                                                    <?php elseif($payment->payment_id == 6): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <form method="post" action="https://secure.payza.com/checkout">
                                                                <?php $order = \App\Order::whereOrder_number($payment->order_number)->first() ?>
                                                                <input type="hidden" name="ap_merchant" value="<?php echo e($payment->payment->val1); ?>"/>
                                                                <input type="hidden" name="ap_purchasetype" value="item"/>
                                                                <input type="hidden" name="ap_itemname" value="Multi Item"/>
                                                                <input type="hidden" name="ap_amount" value="<?php echo e($payment->usd); ?>"/>
                                                                <input type="hidden" name="ap_currency" value="USD"/>
                                                                <input type="hidden" name="ap_description" value="Buy Product From <?php echo e($site_title); ?>"/>
                                                                <input type="hidden" name="ap_itemcode" value="<?php echo e($payment->order_number); ?>"/>
                                                                <input type="hidden" name="ap_quantity" value="1"/>
                                                                <input type="hidden" name="ap_additionalcharges" value="0"/>
                                                                <input type="hidden" name="ap_shippingcharges" value="0"/>
                                                                <input type="hidden" name="ap_taxamount" value="<?php echo e($order->tax); ?>"/>
                                                                <input type="hidden" name="ap_discountamount" value="0"/>
                                                                <input type="hidden" name="ap_returnurl" value="<?php echo e(route('order-complete',$payment->order_number)); ?>"/>
                                                                <input type="hidden" name="ap_cancelurl" value="<?php echo e(route('payment',$payment->order_number)); ?>"/>
                                                                <input type="hidden" name="ap_alerturl" value="<?php echo e(route('payza-ipn')); ?>"/>
                                                                <input type="hidden" name="ap_ipnversion" value="2"/>
                                                                <input type="hidden" name="ap_test" value="1"/>
                                                                <button type="submit" class="btn btn-primary btn-lg text-uppercase btn-block"><i class="fa fa-credit-card"></i>Payment Here</button>
                                                            </form>
                                                        </div>
                                                    <?php elseif($payment->payment_id == 8): ?>
                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                            <form action="https://www.coinpayments.net/index.php" method="post">
                                                                <input type="hidden" name="merchant" value="<?php echo e($payment->payment->val1); ?>">
                                                                <input type="hidden" name="item_name" value="Pay For - <?php echo e($site_title); ?>">
                                                                <input type="hidden" name="currency" value="USD">
                                                                <input type="hidden" name="amountf" value="<?php echo e($payment->usd); ?>">
                                                                <input type="hidden" name="ipn_url" value="<?php echo e(route('coinpayment-ipn')); ?>">
                                                                <input type="hidden" name="custom" value="<?php echo e($payment->order_number); ?>">
                                                                <input type="hidden" name="cmd" value="_pay_simple">
                                                                <input type="hidden" name="want_shipping" value="0">
                                                                <input type="hidden" name="success_url" value="<?php echo e(route('order-complete',$payment->order_number)); ?>">
                                                                <input type="hidden" name="cancel_url" value="<?php echo e(route('payment',$payment->order_number)); ?>">
                                                                <button class="btn btn-primary btn-lg text-uppercase border-0 custom-btnPayment btn-block"><i class="fa fa-btc"></i> Payment Now</button>
                                                            </form>
                                                        </div>
                                                    <?php else: ?>
                                                            <div class="form-group">
                                                                <div class="col-sm-12">
                                                                    <a href="<?php echo e(route('user-all-order')); ?>" class="btn btn-primary btn-lg text-uppercase btn-block"><i class="fa fa-send"></i>Confirm Now</a>
                                                                </div>
                                                            </div>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>