
<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="checkout-section ptb-50">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="checkout-step mb-40">
                        <ul>
                            <li class="active"> <a href="<?php echo e(route('check-out')); ?>">
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">1</div>
                                    </div>
                                    <span>Shipping</span> </a> </li>
                            <li> <a href="<?php echo e(route('oder-overview')); ?>">
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">2</div>
                                    </div>
                                    <span>Order Overview</span> </a> </li>
                            <li> <a>
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">3</div>
                                    </div>
                                    <span>Payment</span> </a> </li>
                            <li> <a>
                                    <div class="step">
                                        <div class="line"></div>
                                        <div class="circle">4</div>
                                    </div>
                                    <span>Order Complete</span> </a> </li>
                            <li>
                                <div class="step">
                                    <div class="line"></div>
                                </div>
                            </li>
                        </ul>
                        <hr>
                    </div>
                    <div class="checkout-content" >
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="heading-part align-center">
                                    <h2 class="heading">Please fill up your Shipping details</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-10 col-md-10 col-sm-10 col-lg-offset-1 col-md-offset-1 col-sm-offset-1">
                                <form action="<?php echo e(route('submit-details')); ?>" class="main-form full" method="post">
                                    <?php echo csrf_field(); ?>

                                    <?php if($userDetails== null): ?>
                                    <div class="mb-20">
                                        <div class="row">
                                            <div class="col-xs-12 mb-20">
                                                <div class="heading-part">
                                                    <h3 class="sidebar-title">Shipping Address</h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="email" name="s_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_company" required placeholder="Company">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_number" required placeholder="Contact Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <select name="s_country" id="shippingcountryid">
                                                        <option selected="" value="">Select Country</option>
                                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_state" required placeholder="State Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_city" required placeholder="City Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="s_zip" required placeholder="Postcode/zip">
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="input-box">
                                                    <textarea name="s_address" required placeholder="Shipping Address"></textarea>
                                                    <span>Please provide the number and street.</span> </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="input-box">
                                                    <input type="text" name="s_landmark" required placeholder="Shipping Landmark">
                                                    <span>Please include landmark (e.g : Opposite Bank) as the carrier service may find it easier to locate your address.</span> </div>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="row">
                                            <div class="col-xs-12 mb-20">
                                                <div class="heading-part">
                                                    <h3 class="sub-heading">Billing Address</h3>
                                                </div>
                                                <hr>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_company" required placeholder="Company">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_number" required placeholder="Contact Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <select name="b_country" id="shippingcountryid">
                                                        <option selected="" value="">Select Country</option>
                                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_state" required placeholder="State Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_city" required placeholder="City Name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="text" name="b_zip" required placeholder="Postcode/zip">
                                                </div>
                                            </div>
                                            <div class="col-sm-12"> <button type="submit" class="btn btn-color btn-block right-side">Next</button> </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="mb-20">
                                            <div class="row">
                                                <div class="col-xs-12 mb-20">
                                                    <div class="heading-part">
                                                        <h3 class="sidebar-title">Shipping Address</h3>
                                                    </div>
                                                    <hr>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="s_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="email" name="s_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="s_company" value="<?php echo e($userDetails->s_company); ?>" required placeholder="Company">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="s_number" value="<?php echo e($userDetails->s_number); ?>" required placeholder="Contact Number">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <select name="s_country" id="shippingcountryid">
                                                            <option selected="" value="">Select Country</option>
                                                            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($userDetails->s_country == $value): ?>
                                                                <option value="<?php echo e($value); ?>" selected><?php echo e($value); ?></option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="s_state" value="<?php echo e($userDetails->s_state); ?>" required placeholder="State Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="s_city" value="<?php echo e($userDetails->s_city); ?>" required placeholder="City Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="s_zip" value="<?php echo e($userDetails->s_zip); ?>" required placeholder="Postcode/zip">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="input-box">
                                                        <textarea name="s_address" required placeholder="Shipping Address"><?php echo e($userDetails->s_address); ?></textarea>
                                                        <span>Please provide the number and street.</span> </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="input-box">
                                                        <input type="text" name="s_landmark" value="<?php echo e($userDetails->s_landmark); ?>" required placeholder="Shipping Landmark">
                                                        <span>Please include landmark (e.g : Opposite Bank) as the carrier service may find it easier to locate your address.</span> </div>
                                                </div>


                                            </div>
                                        </div>
                                        <div class="">
                                            <div class="row">
                                                <div class="col-xs-12 mb-20">
                                                    <div class="heading-part">
                                                        <h3 class="sub-heading">Billing Address</h3>
                                                    </div>
                                                    <hr>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_name" value="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" required placeholder="Full Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_email" value="<?php echo e($user->email); ?>" required placeholder="Email Address">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_company" value="<?php echo e($userDetails->b_company); ?>" required placeholder="Company">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_number" value="<?php echo e($userDetails->b_number); ?>" required placeholder="Contact Number">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <select name="b_country" id="shippingcountryid">
                                                            <option selected="" value="">Select Country</option>
                                                            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($userDetails->b_country == $value): ?>
                                                                <option value="<?php echo e($value); ?>" selected><?php echo e($value); ?></option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_state" value="<?php echo e($userDetails->b_state); ?>" required placeholder="State Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_city" value="<?php echo e($userDetails->b_city); ?>" required placeholder="City Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-box">
                                                        <input type="text" name="b_zip" value="<?php echo e($userDetails->b_zip); ?>" required placeholder="Postcode/zip">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12"> <button type="submit" class="btn btn-color btn-block right-side">Next</button> </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>