
<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->


    <!-- CONTAIN START -->
    <section class="ptb-50">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-4 mb-xs-30">
                    <div class="sidebar-block">
                        <div class="sidebar-box listing-box mb-40"> <span class="opener plus"></span>
                            <div class="sidebar-title">
                                <h3>Categories</h3>
                            </div>
                            <div class="sidebar-contant">
                                <ul>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('category',['id'=>$cat->id,'slug'=>str_slug($cat->name)])); ?>"><i class="fa fa-link"></i><?php echo e($cat->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                        <?php if($ad1 != null): ?>
                            <div class="sidebar-box mb-30 visible-sm visible-md visible-lg hidden-xs">
                                <?php if($ad1->advert_type == 1): ?>
                                    <a href="<?php echo e($ad1->link); ?>" target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad1->val1); ?>" alt="<?php echo e($ad1->title); ?>"></a>
                                <?php else: ?>
                                    <?php echo $ad1->val2; ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div class="sidebar-box sidebar-item"> <span class="opener plus"></span>
                            <div class="sidebar-title">
                                <h3>Best Sell</h3>
                            </div>
                            <div class="sidebar-contant">
                                <ul>
                                    <?php $__currentLoopData = $bestSell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ffp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php $fp = \App\Product::findOrFail($ffp->product_id) ?>

                                        <li>
                                            <div class="pro-media">
                                                <a href="<?php echo e(route('product-details',$fp->slug)); ?>"><img alt="<?php echo e($fp->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($fp->image); ?>"></a>
                                            </div>
                                            <div class="pro-detail-info"> <a href="<?php echo e(route('product-details',$fp->slug)); ?>"><?php echo e(substr($fp->name,0,18)); ?>..</a>
                                                <div class="rating-summary-block right-side">
                                                    <?php
                                                        $totalReview = \App\Review::whereProduct_id($fp->id)->count();
                                                        if ($totalReview == 0){
                                                            $finalRating = 0;
                                                        }else{
                                                            $totalRating = \App\Review::whereProduct_id($fp->id)->sum('rating');
                                                            $finalRating = round($totalRating / $totalReview);
                                                        }
                                                    ?>
                                                    <div class="rating-result">

                                                    </div>
                                                </div>
                                                <div class="price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e($fp->current_price); ?></span>
                                                    <span class="product-rating">
                                                            <?php echo \App\TraitsFolder\CommonTrait::viewRating($finalRating); ?>

                                                        </span>
                                                </div>
                                                <div class="bottom-detail cart-button">
                                                    <ul>
                                                        <li class="pro-cart-icon">
                                                            <button style="padding: 6px 15px" type="button" title="Add to Cart" data-id="<?php echo e($fp->id); ?>" class="btn btn-xs btn-color SingleCartAdd"><span></span>Add to Cart</button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-sm-8">
                    <div class="sidebar-title">
                        <h3><?php echo e($page_title); ?></h3>
                    </div>
                    <div class="product-listing">
                        <?php if(count($tag->products) != 0): ?>
                                <div class="row mlr_-20">

                                    <?php $__currentLoopData = $tag->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-md-4 col-xs-6 plr-20">

                                            <div class="product-item <?php echo e($fp->stock == 0 ? 'sold-out' : ''); ?>">
                                                <?php if($fp->mood_id == 0): ?>
                                                    <div class="sale-label sell-label"><span>Sale</span></div>
                                                <?php elseif($fp->mood_id == 1): ?>
                                                    <div class="sale-label green-label"><span>New</span></div>
                                                <?php elseif($fp->mood_id == 2): ?>
                                                    <div class="sale-label red-label"><span>Hot</span></div>
                                                <?php endif; ?>
                                                <div class="product-image">
                                                    <a href="<?php echo e(route('product-details',$fp->slug)); ?>"> <img src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($fp->image); ?>" alt="<?php echo e($fp->name); ?>"> </a>
                                                    <div class="product-detail-inner">
                                                        <div class="detail-inner-left left-side">
                                                            <ul>
                                                                <li class="pro-cart-icon">
                                                                    <button title="Add to Cart" class="SingleCartAdd" data-id="<?php echo e($fp->id); ?>"><i class="fa fa-cart"></i></button>
                                                                </li>
                                                                <li class="pro-wishlist-icon active"><a class="SingleWishList" data-id="<?php echo e($fp->id); ?>" title="Wishlist"></a></li>
                                                                <li class="pro-compare-icon"><a id="compareId" data-id="<?php echo e($fp->id); ?>" title="Compare"></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-item-details">
                                                    <div class="product-item-name"> <a href="<?php echo e(route('product-details',$fp->slug)); ?>"><?php echo e(substr($fp->name,0,65)); ?></a> </div>
                                                    <div class="price-box">
                                                        <span class="price"><?php echo e($basic->symbol); ?><?php echo e($fp->current_price); ?></span>
                                                        <?php if($fp->old_price != null): ?>
                                                            <del class="price old-price"><?php echo e($basic->symbol); ?><?php echo e($fp->old_price); ?></del>
                                                        <?php endif; ?>
                                                        <div class=" right-side">
                                                            <?php
                                                                $totalReview = \App\Review::whereProduct_id($fp->id)->count();
                                                                if ($totalReview == 0){
                                                                    $finalRating = 0;
                                                                }else{
                                                                    $totalRating = \App\Review::whereProduct_id($fp->id)->sum('rating');
                                                                    $finalRating = round($totalRating / $totalReview);
                                                                }
                                                            ?>
                                                            <div class="rating-result">
                                                            <span class="product-rating">
                                                                <?php echo \App\TraitsFolder\CommonTrait::viewRating($finalRating); ?>

                                                            </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                        <?php else: ?>
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="text-center" style="font-size: 24px;font-weight: bold;">Product Not Found..!</h2>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($ad4 != null): ?>
                        <div class="visible-sm visible-md visible-lg hidden-xs">
                            <?php if($ad4->advert_type == 1): ?>
                                <a href="<?php echo e($ad4->link); ?>" target="_blank"><img  class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad4->val1); ?>" alt="<?php echo e($ad4->title); ?>"></a>
                            <?php else: ?>
                                <?php echo $ad4->val2; ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function() {

            $( "#slider-range" ).slider({
                range: true,
                min: 0,
                max: 1000,
                values: [ 180, 800 ],
                slide: function( event, ui ) {
                    $( "#amount" ).val("<?php echo e($basic->symbol); ?>"+ui.values[ 0 ]+"-<?php echo e($basic->symbol); ?>" + ui.values[ 1 ]);
                }
            });
            $( "#amount" ).val("<?php echo e($basic->symbol); ?>"+$( "#slider-range" ).slider("values",0)+ "-<?php echo e($basic->symbol); ?>"+$( "#slider-range" ).slider( "values", 1));
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>