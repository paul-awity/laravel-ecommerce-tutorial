
<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="checkout-section ptb-50">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">

                    <div class="checkout-content">
                        <div id="cartFullView" class="row">
                            <div class="col-xs-12 mb-xs-30">
                                <div class="sidebar-title">
                                    <h3>Wishlist Products</h3>
                                </div>
                                <div class="cart-item-table commun-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Product Image</th>
                                                <th>Product Name</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Add Cart</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <a href="<?php echo e(route('product-details',$con->product->slug)); ?>">
                                                            <div class="product-image"><img alt="<?php echo e($con->product->name); ?>" src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($con->product->image); ?>"></div>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <div class="product-title">
                                                            <a href="<?php echo e(route('product-details',$con->product->slug)); ?>"><?php echo e($con->product->name); ?></a>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <ul>
                                                            <li>
                                                                <div class="base-price price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e($con->product->current_price); ?></span> </div>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                    <td>
                                                        <div class="input-box">
                                                            <div class="custom-qty">
                                                                <button onclick="var result = document.getElementById('qty<?php echo e($con->id); ?>'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button"> <i class="fa fa-minus"></i> </button>
                                                                <input type="text" class="input-text qty" readonly title="Qty" value="1" maxlength="<?php echo e($con->product->stock); ?>" id="qty<?php echo e($con->id); ?>" name="qty">
                                                                <button onclick="var result = document.getElementById('qty<?php echo e($con->id); ?>'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button"> <i class="fa fa-plus"></i> </button>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <button data-id="<?php echo e($con->product_id); ?>" id="wish<?php echo e($con->id); ?>" class="btn btn-color"><i class="fa fa-cart-plus"></i> Add Cart</button>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger delete_button"
                                                                data-toggle="modal" data-target="#DelModal"
                                                                data-id="<?php echo e($con->id); ?>">
                                                            <i class='fa fa-trash'></i>Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-sm-12">
                                <div><a href="<?php echo e(route('home')); ?>" class="btn btn-block btn-color"><span><i class="fa fa-angle-left"></i></span>Back To Home</a> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->

    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> <strong>Confirmation !</strong></h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete ?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('wishlist-delete')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <input type="hidden" name="id" class="delete_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> DELETE</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".delete_id").val(id);
            });
        });
    </script>

    <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <script>
            var url = '<?php echo e(url('/')); ?>';
            $(document).ready(function () {
                $(document).on("click", '#wish<?php echo e($con->id); ?>', function (e) {

                    $.post(
                        '<?php echo e(url('/wishlist-to-cart')); ?>',
                        {
                            _token: '<?php echo e(csrf_token()); ?>',
                            id : $(this).data('id'),
                            qty : $('#qty<?php echo e($con->id); ?>').val()
                        },
                        function(data) {
                            var result = $.parseJSON(data);
                            if (result['cartError'] == "yes"){
                                toastr.warning(result['cartErrorMessage']);
                            }else{
                                toastr.success('Cart Updated Successfully.');
                                $('#cartShow').empty();
                                $('#cartShow').append(result['cartShowFinal']);
                                $('#cartFullView').empty();
                                var div = document.getElementById('cartFullView');
                                div.innerHTML = result['all'];
                            }
                        }
                    );
                });
            });
        </script>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>