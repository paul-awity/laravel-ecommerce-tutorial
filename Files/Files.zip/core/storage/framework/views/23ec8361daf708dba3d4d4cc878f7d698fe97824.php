
<?php $__env->startSection('meta'); ?>
    <meta name="keywords" content="<?php echo $tags; ?>">
    <meta name="description" content="<?php echo e(strip_tags($product->description)); ?>">
    <meta property="og:title" content="<?php echo e($product->name); ?>" />
    <meta property="og:url" content="<?php echo e(url()->current()); ?>" />
    <meta property="og:image" content="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($product->image); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <!-- BANNER STRAT -->
    <div class="banner inner-banner align-center" style="background-image: url('<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>');">
        <div class="container">
            <section class="banner-detail">
                <h1 class="banner-title"><?php echo e($page_title); ?></h1>
                <div class="bread-crumb right-side">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a>/</li>
                        <li><span><?php echo e($page_title); ?></span></li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
    <!-- BANNER END -->

    <!-- CONTAIN START -->
    <section class="pt-50">
        <div class="container">
            <div class="row">
                <div class="col-md-3  mb-xs-30">
                    <div class="sidebar-block">
                        <div class="sidebar-box listing-box mb-40"> <span class="opener plus"></span>
                            <div class="sidebar-title">
                                <h3>Categories</h3>
                            </div>
                            <div class="sidebar-contant">
                                <ul>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('category',['id'=>$cat->id,'slug'=>str_slug($cat->name)])); ?>"><i class="fa fa-link"></i><?php echo e($cat->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php if($ad2 != null): ?>
                        <div class="sidebar-box mb-30 visible-sm visible-md visible-lg hidden-xs">
                            <?php if($ad2->advert_type == 1): ?>
                                <a href="<?php echo e($ad1->link); ?>"  target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad2->val1); ?>" alt="<?php echo e($ad2->title); ?>"></a>
                            <?php else: ?>
                                <?php echo $ad2->val2; ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-5 col-sm-5 mb-xs-30">
                    <div class="fotorama" data-nav="thumbs" data-allowfullscreen="native">
                        <?php $__currentLoopData = $productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#"><img src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($pi->name); ?>" alt="<?php echo e($product->name); ?>"></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-4 col-sm-7">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="product-detail-main">
                                <div class="product-item-details">
                                    <h1 class="product-item-name single-item-name"><?php echo e($product->name); ?></h1>
                                    <div class="rating-summary-block">
                                        <div class="rating-result single-rating">
                                            <?php
                                                $totalReview = \App\Review::whereProduct_id($product->id)->count();
                                                if ($totalReview == 0){
                                                    $finalRating = 0;
                                                }else{
                                                    $totalRating = \App\Review::whereProduct_id($product->id)->sum('rating');
                                                    $finalRating = round($totalRating / $totalReview);
                                                }
                                            ?>
                                            <p>
                                                <span class="review_score"><?php echo e($finalRating); ?>/5</span><?php echo \App\TraitsFolder\CommonTrait::viewRating($finalRating); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <div class="price-box"> <span class="price"><?php echo e($basic->symbol); ?><?php echo e($product->current_price); ?></span> <?php if($product->old_price != null): ?><del class="price old-price bold"><?php echo e($basic->symbol); ?><?php echo e($product->old_price); ?></del><?php endif; ?></div>
                                    <div class="product-info-stock-sku">
                                        <div>
                                            <label>Availability: </label>
                                            <?php if($product->stock == 0): ?>
                                                <span class="info-deta">Not Available</span>
                                            <?php elseif($product->stock < 10): ?>
                                                <span class="info-deta">Low Available</span>
                                            <?php else: ?>
                                                <span class="info-deta">In stock</span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <label>SKU: </label>
                                            <span class="info-deta"><?php echo e($product->sku); ?></span>
                                        </div>
                                        <?php if($product->provider_id != 0): ?>
                                        <div>
                                            <label>Provider : </label>
                                            <span class="info-deta"><a href="<?php echo e(route('get-provider-product',$product->provider_id)); ?>"><?php echo e($product->provider->name); ?></a></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <form action="" method="post">
                                    <?php if($product->color_status == 1): ?>
                                        <div class="product-color select-arrow mb-20">
                                            <label>Color</label>
                                            <select class="selectpicker form-control" id="color">
                                                <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($product->size_status == 1): ?>
                                        <div class="product-size select-arrow mb-20 mt-30">
                                            <label>Size</label>
                                            <select class="selectpicker form-control" id="size">
                                                <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                    <div class="mb-40">
                                            <?php echo csrf_field(); ?>

                                            <div class="product-qty">
                                                <label for="qty">Qty:</label>
                                                <div class="custom-qty">
                                                    <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button"> <i class="fa fa-minus"></i> </button>
                                                    <input type="text" class="input-text qty" title="Qty" value="1" max="<?php echo e($product->stock); ?>" id="qty" name="qty" required>
                                                    <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button"> <i class="fa fa-plus"></i> </button>
                                                </div>
                                            </div>
                                            <input type="hidden" name="product_id" id="product_id" value="<?php echo e($product->id); ?>">
                                            <div class="bottom-detail cart-button">
                                                <ul>
                                                    <li class="pro-cart-icon">
                                                        <button type="button" title="Add to Cart" class="btn-black addCart"><span></span>Add to Cart</button>
                                                    </li>
                                                </ul>
                                            </div>
                                    </div>
                                    </form>
                                    <div class="product-info-stock-sku">
                                        <div>
                                            <label>Product Specification: </label>
                                            <hr>
                                            <br>
                                            <?php $__currentLoopData = $productSpecification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e($ps->specification); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="bottom-detail">
                                        <ul>

                                            <li class="pro-wishlist-icon"><a class="SingleWishList" data-id="<?php echo e($product->id); ?>"><span></span>Wishlist</a></li>
                                            <li class="pro-compare-icon"><a id="compareId" data-id="<?php echo e($product->id); ?>" ><span></span>Compare</a></li>
                                            <li class="pro-email-icon"><a data-toggle="modal" data-target="#email_friends_modal"><span></span>Email</a></li>
                                        </ul>
                                    </div>
                                    <div class="share-link">
                                        <div class="social-link">
                                            <div class="sharethis-inline-share-buttons st-inline-share-buttons  st-left st-has-labels st-animated" id="st-1">
                                                <script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ptb-50">
        <div class="container">
            <div class="product-detail-tab">
                <div class="row">
                    <div class="col-md-12">
                        <div id="tabs">
                            <ul class="nav nav-tabs">
                                <li><a class="tab-Description selected" title="Description">Description</a></li>
                                <li><a class="tab-Product-Tags" title="Product-Tags">Product-Tags</a></li>
                                <li><a class="tab-Reviews" title="Reviews">Reviews</a></li>
                                <li><a class="tab-Comments" title="Comments">Comments</a></li>
                            </ul>
                        </div>
                        <div id="items">
                            <div class="tab_content">
                                <ul>
                                    <li>
                                        <div class="items-Description selected gray-bg">
                                            <div class="Description">
                                                <?php echo $product->description; ?>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="items-Product-Tags gray-bg">
                                            <?php $__currentLoopData = $product->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(route('tag-products',$pTag->id)); ?>" class="label label-primary" style="font-size: 14px">#<?php echo e($pTag->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="items-Reviews gray-bg">
                                            <div class="comments-area">
                                                <h3 class="form-label">Reviews <span>(<?php echo e(count($productReviews)); ?>)</span></h3>
                                                <ul class="comment-list mt-30">
                                                    <?php $__currentLoopData = $productReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <div class="comment-user">
                                                            <img class="img-circle" width="80%" src="<?php echo e(asset('assets/images/user')); ?>/<?php echo e($rv->user->image); ?>" alt="<?php echo e($rv->user->name); ?>"> </div>
                                                        <div class="comment-detail">
                                                            <div class="user-name"><?php echo e($rv->user->first_name); ?> <?php echo e($rv->user->last_name); ?></div>
                                                            <div class="post-info">
                                                                <ul>
                                                                    <li><?php echo e(\Carbon\Carbon::parse($rv->created_at)->format('M d, Y - h:i:s A')); ?></li>
                                                                </ul>
                                                            </div>
                                                            <p style="margin-bottom: 0px"><?php echo \App\TraitsFolder\CommonTrait::viewRating($rv->rating); ?> - <span class="review_score"><?php echo e($rv->rating); ?>/5</span></p>
                                                            <p><?php echo e($rv->comment); ?></p>
                                                        </div>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                            <div class="main-form mt-30">
                                                <div class="row">
                                                    <?php if(Auth::check()): ?>

                                                        <?php $userReviewCount = \App\Review::whereUser_id(Auth::user()->id)->whereProduct_id($product->id)->count();?>

                                                        <?php if($userReviewCount != 0): ?>
                                                            <?php $userReview = \App\Review::whereUser_id(Auth::user()->id)->whereProduct_id($product->id)->first();?>
                                                            <div class="comments-area">
                                                                <h3 class="form-label">Your Review</h3>
                                                                <ul class="comment-list mt-30">
                                                                    <li>
                                                                        <div class="comment-user">
                                                                            <img class="img-circle" width="80%" src="<?php echo e(asset('assets/images/user')); ?>/<?php echo e($userReview->user->image); ?>" alt="<?php echo e($userReview->user->name); ?>"> </div>
                                                                        <div class="comment-detail">
                                                                            <div class="user-name"><?php echo e($userReview->user->first_name); ?> <?php echo e($userReview->user->last_name); ?></div>
                                                                            <div class="post-info">
                                                                                <ul>
                                                                                    <li><?php echo e(\Carbon\Carbon::parse($userReview->created_at)->format('M d, Y - h:i:s A')); ?></li>
                                                                                </ul>
                                                                            </div>
                                                                            <p style="margin-bottom: 0px"><?php echo \App\TraitsFolder\CommonTrait::viewRating($userReview->rating); ?> - <span class="review_score"><?php echo e($rv->rating); ?>/5</span></p>
                                                                            <p><?php echo e($userReview->comment); ?></p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        <?php else: ?>
                                                        <form action="<?php echo e(route('review-submit')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                            <div class="col-xs-12">
                                                                <?php if($errors->any()): ?>
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="alert alert-danger alert-dismissable">
                                                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                                            <?php echo $error; ?>

                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">Rating for Product</label>
                                                                    <div class="listing_rating">
                                                                        <input name="rating" id="rating-1" value="5" type="radio" required="">
                                                                        <label for="rating-1" class="fa fa-star"></label>
                                                                        <input name="rating" id="rating-2" value="4" type="radio" required="">
                                                                        <label for="rating-2" class="fa fa-star"></label>
                                                                        <input name="rating" id="rating-3" value="3" type="radio" required="">
                                                                        <label for="rating-3" class="fa fa-star"></label>
                                                                        <input name="rating" id="rating-4" value="2" type="radio" required="">
                                                                        <label for="rating-4" class="fa fa-star"></label>
                                                                        <input name="rating" id="rating-5" value="1" type="radio" required="">
                                                                        <label for="rating-5" class="fa fa-star"></label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">Rating Comment</label>
                                                                    <textarea cols="30" rows="3" name="comment" placeholder="Message" required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-color btn-block" type="submit">Submit</button>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-danger btn-block" style="border: none" type="reset">Reset</button>
                                                            </div>
                                                        </form>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <form action="<?php echo e(route('login')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <div class="col-xs-12 mb-20">
                                                                <div class="sidebar-title">
                                                                    <h3>Need Log In</h3>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <?php if($errors->any()): ?>
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="alert alert-danger alert-dismissable">
                                                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                                            <?php echo $error; ?>

                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">E-mail Address</label>
                                                                    <input id="login-email" name="email" type="email" value="<?php echo e(old('email')); ?>" required placeholder="Email Address">
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">Password</label>
                                                                    <input id="login-pass" name="password" type="password" required placeholder="Enter your Password">
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-color btn-block" type="submit">Log In</button>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-danger btn-block" style="border: none" type="reset">Reset</button>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="new-account align-center mt-20"> <span>Need new  Account ?</span> <a class="link" title="Register" href="<?php echo e(route('register')); ?>">Create New Account</a> </div>
                                                            </div>
                                                        </form>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="items-Comments gray-bg">
                                            <div class="comments-area">
                                                <h4>Comments <span>(<?php echo e(count($productComment)); ?>)</span></h4>
                                                <ul class="comment-list mt-30">
                                                    <?php $__currentLoopData = $productComment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <div class="comment-user">
                                                                <img class="img-circle" width="80%" src="<?php echo e(asset('assets/images/user')); ?>/<?php echo e($rv->user->image); ?>" alt="<?php echo e($rv->user->name); ?>"> </div>
                                                            <div class="comment-detail">
                                                                <div class="user-name"><?php echo e($rv->user->first_name); ?> <?php echo e($rv->user->last_name); ?></div>
                                                                <div class="post-info">
                                                                    <ul>
                                                                        <li><?php echo e(\Carbon\Carbon::parse($rv->created_at)->format('M d, Y - h:i:s A')); ?></li>
                                                                    </ul>
                                                                </div>
                                                                <p><?php echo e($rv->comment); ?></p>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                            </div>
                                            <div class="main-form mt-30">
                                                <h4>Leave a comments</h4>
                                                <div class="row mt-30">
                                                    <?php if(Auth::check()): ?>

                                                        <form action="<?php echo e(route('comment-submit')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                            <div class="col-xs-12">
                                                                <?php if($errors->any()): ?>
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="alert alert-danger alert-dismissable">
                                                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                                            <?php echo $error; ?>

                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </div>

                                                            <div class="col-xs-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">Comment</label>
                                                                    <textarea cols="30" rows="3" name="comment" placeholder="Comment" required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-color btn-block" type="submit">Submit</button>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-danger btn-block" style="border: none" type="reset">Reset</button>
                                                            </div>
                                                        </form>
                                                    <?php else: ?>
                                                        <form action="<?php echo e(route('login')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>

                                                            <div class="col-xs-12 mb-20">
                                                                <div class="sidebar-title">
                                                                    <h3>Need Log In</h3>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <?php if($errors->any()): ?>
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="alert alert-danger alert-dismissable">
                                                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                                            <?php echo $error; ?>

                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">E-mail Address</label>
                                                                    <input id="login-email" name="email" type="email" value="<?php echo e(old('email')); ?>" required placeholder="Email Address">
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="form-group">
                                                                    <label class="form-label">Password</label>
                                                                    <input id="login-pass" name="password" type="password" required placeholder="Enter your Password">
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-color btn-block" type="submit">Log In</button>
                                                            </div>
                                                            <div class="col-xs-6 mb-30">
                                                                <button class="btn-danger btn-block" style="border: none" type="reset">Reset</button>
                                                            </div>
                                                            <div class="col-xs-12">
                                                                <div class="new-account align-center mt-20"> <span>Need new  Account ?</span> <a class="link" title="Register" href="<?php echo e(route('register')); ?>">Create New Account</a> </div>
                                                            </div>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if($ad4 != null): ?>
        <div class="mb-20 visible-sm visible-md visible-lg hidden-xs">
            <?php if($ad4->advert_type == 1): ?>
                <a href="<?php echo e($ad4->link); ?>" target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad4->val1); ?>" alt="<?php echo e($ad4->title); ?>"></a>
            <?php else: ?>
                <?php echo $ad4->val2; ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
    <section class="pb-95">
        <div class="container">
            <div class="product-slider">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="heading-part mb-20">
                            <h2 class="main_title">Related Products</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="product-slider-main position-r"><!-- dresses -->
                        <div class="owl-carousel pro_rel_slider"><!-- id="product-slider" -->
                            <?php $__currentLoopData = $relatedProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="product-item">
                                    <?php if($rp->mood_id == 0): ?>
                                        <div class="sale-label sell-label"><span>Sale</span></div>
                                    <?php elseif($rp->mood_id == 1): ?>
                                        <div class="sale-label green-label"><span>New</span></div>
                                    <?php elseif($rp->mood_id == 2): ?>
                                        <div class="sale-label red-label"><span>Hot</span></div>
                                    <?php endif; ?>
                                    <div class="product-image"> <a href="<?php echo e(route('product-details',$rp->slug)); ?>"> <img src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($rp->image); ?>" alt="<?php echo e($rp->name); ?>"> </a>
                                        <div class="product-detail-inner">
                                            <div class="detail-inner-left left-side">
                                                <ul>
                                                    <li class="pro-cart-icon">
                                                        <button title="Add to Cart" class="SingleCartAdd" data-id="<?php echo e($rp->id); ?>"><i class="fa fa-cart"></i></button>
                                                    </li>
                                                    <li class="pro-wishlist-icon"><a class="SingleWishList" data-id="<?php echo e($rp->id); ?>" title="Wishlist"></a></li>
                                                    <li class="pro-compare-icon"><a id="compareId" data-id="<?php echo e($rp->id); ?>" title="Compare"></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-item-details">
                                        <div class="product-item-name"> <a href="<?php echo e(route('product-details',$rp->slug)); ?>"><?php echo e(substr($rp->name,0,65)); ?></a> </div>
                                        <div class="price-box">
                                            <span class="price"><?php echo e($basic->symbol); ?><?php echo e($rp->current_price); ?></span> <?php if($product->old_price != null): ?><del class="price old-price bold"><?php echo e($basic->symbol); ?><?php echo e($rp->old_price); ?></del><?php endif; ?>
                                            <div class="rating-summary-block right-side">
                                                <div title="53%" class="rating-result"> <span style="width:53%"></span> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->

    <div id="email_friends_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" style="display: none;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <h3 class="modal-title ">Email to Friend</h3>
                </div>
                <div class="modal-body">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $error; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <form action="<?php echo e(route('submit-friend-email')); ?>" method="post" role="form" >
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input class="form-control" name="name" placeholder="Your Name" type="text" data-error="Please enter name field." required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" name="ownEmail" placeholder="Your Email Address" type="email" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" name="friendEmail" placeholder="Friend Email Address" type="email" required>
                        </div>
                        <input type="hidden" name="url" value="<?php echo e(url()->current()); ?>">
                        <div class="form-group">
                            <input value="Submit" class="btn btn-block btn-primary btn-color" type="submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <meta name="_token" content="<?php echo csrf_token(); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {
            $(document).on("click", '#compareId', function (e) {
                var id = $(this).data('id');
                var url = '<?php echo e(url('/')); ?>';

                $.get(url + '/compare-add/' + id,function (data) {

                    var result = $.parseJSON(data);

                    if (result['errorStatus'] == "yes"){
                        toastr.warning(result['errorDetails']);
                    }else{
                        toastr.success(result['errorDetails']);
                    }
                });
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $( "#slider-range" ).slider({
                range: true,
                min: 0,
                max: 1000,
                values: [ 180, 800 ],
                slide: function( event, ui ) {
                    $( "#amount" ).val("<?php echo e($basic->symbol); ?>"+ui.values[ 0 ]+"-<?php echo e($basic->symbol); ?>" + ui.values[ 1 ]);
                }
            });
            $( "#amount" ).val("<?php echo e($basic->symbol); ?>"+$( "#slider-range" ).slider("values",0)+ "-<?php echo e($basic->symbol); ?>"+$( "#slider-range" ).slider( "values", 1));
        });
    </script>
    <script>

        var url = '<?php echo e(url('/add-to-cart')); ?>';

        $(".addCart").click(function (e) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            e.preventDefault();
            var formData = {
                product_id: $('#product_id').val(),
                qty: $('#qty').val(),
                size : $('#size').val(),
                color : $('#color').val()
            };
            var type = "POST";
            var my_url = url;
            console.log(formData);
            $.ajax({
                type: type,
                url: my_url,
                data: formData,
                success: function (data) {
                    var result = $.parseJSON(data);
                    if (result['cartError'] == "yes"){
                        toastr.warning(result['cartErrorMessage']);
                    }else{
                        toastr.success('Product Added To Cart.');
                        $('#cartShow').empty();
                        $('#cartShow').append(result['cartShowFinal']);
                    }
                },
                error: function(data)
                {
                    $.each( data.responseJSON.errors, function( key, value ) {
                        toastr.error( value);
                    });
                }
            });
        });


    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>