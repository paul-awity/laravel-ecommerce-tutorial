<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/pricing.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-primary btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div>
                    <!-- /. tools -->
                </div>
                <!-- /.box-header -->
                <div class="box-body pad">


                            <table class="table table-striped table-bordered table-hover" id="sample_1">
                                <thead>
                                <tr>
                                    <th>#SL</th>
                                    <th>Method Name</th>
                                    <th>Display Image</th>
                                    <th>Withdraw Charge</th>
                                    <th>Withdraw Limit</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($pm->status == 0 ? 'bg-warning' : ''); ?>">
                                        <td><b><?php echo e(++$key); ?></b></td>
                                        <td><b><?php echo e($pm->name); ?></b></td>
                                        <td><img src="<?php echo e(asset('assets/images/withdraw')); ?>/<?php echo e($pm->image); ?>" width="50%" alt=""></td>
                                        <td><b><?php echo e($pm->charge); ?> <?php echo e($basic->currency); ?></b></td>
                                        <td><b><?php echo e($pm->withdraw_min); ?><?php echo e($basic->currency); ?> ~ <?php echo e($pm->withdraw_max); ?><?php echo e($basic->currency); ?></b></td>
                                        <td><b><?php echo e($pm->duration); ?> Days</b></td>
                                        <td>
                                            <?php if($pm->status == 1): ?>
                                                <div class="badge badge-primary"><i class="fa fa-check font-medium-1"></i><span class="text-bold-700 text-uppercase">Activate</span></div>
                                            <?php else: ?>
                                                <div class="badge badge-danger"><i class="fa fa-times font-medium-1"></i><span class="text-bold-700 text-uppercase">Deactivate</span></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('withdraw-edit',$pm->id)); ?>" class="btn btn-primary btn-sm bold"><i class="fa fa-edit"></i> EDIT</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                </div>
            </div>
        </div>
    </div>




    

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>