
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <div class="box box-primary box-solid">
        <div class="box-header with-border">
            <h3 class="box-title"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></h3>
            <!-- tools box -->
            <div class="pull-right box-tools">
                <button type="button" class="btn btn-primary btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-primary btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
            </div>
            <!-- /. tools -->
        </div>
        <!-- /.box-header -->
        <div class="box-body pad">

            <?php echo Form::open(['method'=>'post','files'=>true]); ?>

            <div class="row">
            <div class="col-md-4 col-sm-12">

                <div class="box box-primary box-solid">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-paypal"></i> Paypal</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body pad">

                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><i class="fa fa-cc-paypal"></i> PayPal Details</h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-12">
                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($paypal->image); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                            <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="paypal_image" accept="image/*">
                                                </span>
                                                <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>

                                            </div>
                                            <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="paypal_name" value="<?php echo e($paypal->name); ?>" type="text" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="paypal_rate" value="<?php echo e($paypal->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="paypal_fix" value="<?php echo e($paypal->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="paypal_percent" value="<?php echo e($paypal->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>

                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group" style="margin-top: 40px;margin-bottom: 135px;">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">PayPal Business Email</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="paypal_email" value="<?php echo e($paypal->val1); ?>" required type="text">
                                            <span class="input-group-addon"><b>@</b></span>
                                        </div>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($paypal->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="paypal_status">
                                    </div>
                                </div>
                                <br>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="box box-primary box-solid">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-money"></i> Perfect Money </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body pad">

                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-credit-card-alt"></i> Perfect Money</strong></h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-12">
                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($perfect->image); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                            <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="perfect_image" accept="image/*">
                                                </span>
                                                <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                            </div>
                                            <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="perfect_name" value="<?php echo e($perfect->name); ?>" required type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="perfect_rate" value="<?php echo e($perfect->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="perfect_fix" value="<?php echo e($perfect->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="perfect_percent" value="<?php echo e($perfect->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Perfect Money USD Account</strong></label>
                                    <div class="col-md-12" style="margin-bottom: 21px;">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="perfect_account" value="<?php echo e($perfect->val1); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-send"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Perfect Money Alternate Passphrase  </strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="perfect_alternate" value="<?php echo e($perfect->val2); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-bolt"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($perfect->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="perfect_status">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="box box-primary box-solid">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-btc"></i> BTC ( BlockChain ) </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body pad">

                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-btc"></i> BlockChain - (BITCOIN)</strong></h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-12">
                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($btc->image); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                            <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="btc_image" accept="image/*">
                                                </span>
                                                <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                            </div>
                                            <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="btc_name" value="<?php echo e($btc->name); ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="btc_rate" value="<?php echo e($btc->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="btc_fix" value="<?php echo e($btc->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="btc_percent" value="<?php echo e($btc->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">BitCoin API Key</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="btc_api" value="<?php echo e($btc->val1); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <br>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">BitCoin XPUB Code  </strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="btc_xpub" value="<?php echo e($btc->val2); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-code"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($btc->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="btc_status">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-money"></i> Skrill </h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-money"></i> Skrill</strong></h1>
                                </div>
                                <div class="panel-body">

                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                        <div class="col-md-12">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                    <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($skrill->image); ?>" alt="...">
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                                <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="skrill_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                                </div>
                                                <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                        <div class="col-md-12">
                                            <input class="form-control" name="skrill_name" value="<?php echo e($skrill->name); ?>" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <span class="input-group-addon"><strong>1 USD = </strong></span>
                                                <input class="form-control" name="skrill_rate" value="<?php echo e($skrill->rate); ?>" type="text" required>
                                                <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="skrill_fix" value="<?php echo e($skrill->fix); ?>" required type="text">
                                                        <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="skrill_percent" value="<?php echo e($skrill->percent); ?>" required type="text">
                                                        <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div><!-- row 2nd   -->
                                </div>
                            </div>
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">merchant  email</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <input class="form-control" name="skrill_email" value="<?php echo e($skrill->val1); ?>" type="text">
                                                <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                    <br>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">secret Word</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <input class="form-control" name="skrill_secret" value="<?php echo e($skrill->val2); ?>" type="text">
                                                <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                        <div class="col-md-12">
                                            <input data-toggle="toggle" <?php echo e($skrill->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="skrill_status">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-money"></i> Payza </h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-money"></i> Payza</strong></h1>
                                </div>
                                <div class="panel-body">

                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                        <div class="col-md-12">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                    <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($payza->image); ?>" alt="...">
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                                <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="payza_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                                </div>
                                                <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                        <div class="col-md-12">
                                            <input class="form-control" name="payza_name" value="<?php echo e($payza->name); ?>" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <span class="input-group-addon"><strong>1 USD = </strong></span>
                                                <input class="form-control" name="payza_rate" value="<?php echo e($payza->rate); ?>" type="text" required>
                                                <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="payza_fix" value="<?php echo e($payza->fix); ?>" required type="text">
                                                        <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="payza_percent" value="<?php echo e($payza->percent); ?>" required type="text">
                                                        <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div><!-- row 2nd   -->
                                </div>
                            </div>
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="form-group" style="margin-top: 40px;margin-bottom: 135px;">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">merchant Email</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <input class="form-control" name="payza_email" value="<?php echo e($payza->val1); ?>" required type="text">
                                                <span class="input-group-addon"><b>@</b></span>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                        <div class="col-md-12">
                                            <input data-toggle="toggle" <?php echo e($payza->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="payza_status">
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-credit-card"></i> Credit Card </h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-cc-stripe"></i> Stripe (CARD)</strong></h1>
                                </div>
                                <div class="panel-body">

                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                        <div class="col-md-12">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                    <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($stripe->image); ?>" alt="...">
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                                <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="stripe_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                                                </div>
                                                <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                        <div class="col-md-12">
                                            <input class="form-control" name="stripe_name" value="<?php echo e($stripe->name); ?>" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <span class="input-group-addon"><strong>1 USD = </strong></span>
                                                <input class="form-control" name="stripe_rate" value="<?php echo e($stripe->rate); ?>" type="text" required>
                                                <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="stripe_fix" value="<?php echo e($stripe->fix); ?>" required type="text">
                                                        <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="stripe_percent" value="<?php echo e($stripe->percent); ?>" required type="text">
                                                        <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div><!-- row 2nd   -->
                                </div>
                            </div>
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">SECRET KEY</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <input class="form-control" name="stripe_secret" value="<?php echo e($stripe->val1); ?>" type="text">
                                                <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                    <br>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">PUBLISHER KEY</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <input class="form-control" name="stripe_publishable" value="<?php echo e($stripe->val2); ?>" type="text">
                                                <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                        <div class="col-md-12">
                                            <input data-toggle="toggle" <?php echo e($stripe->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="stripe_status">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-12">

                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-money"></i> Cash On Delivery</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body pad">

                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><i class="fa fa-money"></i> Method Details</h1>
                                </div>
                                <div class="panel-body">

                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                        <div class="col-md-12">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail" style="width: 290px; height: 190px;" data-trigger="fileinput">
                                                    <img style="width: 290px" src="<?php echo e(asset('assets/images/payment')); ?>/<?php echo e($cod->image); ?>" alt="...">
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 290px; max-height: 190px"></div>
                                                <div>
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="cod_image" accept="image/*">
                                                </span>
                                                    <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>

                                                </div>
                                                <b style="color: red;">Image Type PNG,JPEG,JPG. Resize - (290X190)</b><br>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                        <div class="col-md-12">
                                            <input class="form-control" name="cod_name" value="<?php echo e($cod->name); ?>" type="text" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                        <div class="col-md-12">
                                            <div class="input-group mb15">
                                                <span class="input-group-addon"><strong>1 USD = </strong></span>
                                                <input class="form-control" name="cod_rate" value="<?php echo e($cod->rate); ?>" type="text" required>
                                                <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="cod_fix" value="<?php echo e($cod->fix); ?>" required type="text">
                                                        <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                                <div class="col-md-12">
                                                    <div class="input-group mb15">
                                                        <input class="form-control" name="cod_percent" value="<?php echo e($cod->percent); ?>" required type="text">
                                                        <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div><!-- row 2nd   -->
                                </div>
                            </div>

                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Status</h1>
                                </div>
                                <div class="panel-body">
                                    <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                        <div class="col-md-12">
                                            <input data-toggle="toggle" <?php echo e($cod->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="cod_status">
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <button class="btn btn-primary btn-lg btn-block"><i class="fa fa-send"></i> <strong>Save Changes</strong></button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>