<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- BANNER STRAT -->
    <div class="banner">
        <div class="row">
            <div class="col-xs-12">
                <div class="main-banner">
                    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item"> <img src="<?php echo e(asset('assets/images/slider')); ?>/<?php echo e($sli->image); ?>" alt="MarketShop">
                        <div class="banner-detail">
                            <div class="container">
                                <div class="banner-detail-inner">
                                    <h1 class="banner-title"><?php echo e($sli->main_title); ?></h1>
                                    <span class="slogan"><?php echo e($sli->sub_title); ?></span><br>
                                    <p><?php echo e($sli->short_title); ?></p>
                                    <a href="#" class="btn btn-color">Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- BANNER END -->

    <!--  Site Services Features Block Start  -->
    <section class="pt-50 pt-xs-30">
        <div class="container">
            <div class="ser-feature-block center-sm" style="background-image: url('<?php echo e(asset('assets/images/speciality')); ?>/<?php echo e($basic->speciality_bg); ?>')">
                <div class="row">
                    <?php $__currentLoopData = $speciality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-xs-6 feature-box-main">
                        <div class="feature-box feature1" style="background: url('<?php echo e(asset('assets/images/speciality')); ?>/<?php echo e($sp->image); ?>') no-repeat scroll 0 0;filter: brightness(0) invert(1);">
                            <div class="ser-title"><?php echo e($sp->title); ?></div>
                            <div class="ser-subtitle"><?php echo e($sp->subtitle); ?></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
    <!--  Site Services Features Block End  -->

    <!-- CONTAIN START -->
    <section class="ptb-50 ptb-xs-30">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-4 mb-xs-30">
                    <div class="sidebar-block">
                        <div class="sidebar-box listing-box mb-30"> <span class="opener plus"></span>
                            <div class="sidebar-title">
                                <h3>Categories</h3>
                            </div>
                            <div class="sidebar-contant">
                                <ul>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('category',['id'=>$cat->id,'slug'=>str_slug($cat->name)])); ?>"><i class="fa fa-link"></i><?php echo e($cat->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                        <?php if($ad2 != null): ?>
                            <div class="sidebar-box mb-30 visible-sm visible-md visible-lg hidden-xs">
                                <?php if($ad2->advert_type == 1): ?>
                                    <a href="<?php echo e($ad2->link); ?>" target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad2->val1); ?>" alt="<?php echo e($ad2->title); ?>"></a>
                                <?php else: ?>
                                    <?php echo $ad2->val2; ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="sidebar-box gray-box mb-40"> <span class="opener plus"></span>
                            <div class="sidebar-title">
                                <h3>Product Filter</h3>
                            </div>
                            <div class="sidebar-contant">
                                <div class="price-range mb-30">
                                    <form action="<?php echo e(route('product-price-range')); ?>" method="get">
                                        <input class="price-txt" name="range_price" type="text" id="amount">
                                        <div id="slider-range"></div><br>
                                        <button type="submit" class="btn btn-color btn-block btn-sm" style="font-size: 16px"><i class="fa fa-sliders"></i> Filter Products</button>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <?php if($ad1 != null): ?>
                        <div class="sidebar-box mb-30 visible-sm visible-md visible-lg hidden-xs">
                            <?php if($ad1->advert_type == 1): ?>
                                <a href="<?php echo e($ad1->link); ?>" target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad1->val1); ?>" alt="<?php echo e($ad1->title); ?>"></a>
                            <?php else: ?>
                                <?php echo $ad1->val2; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-9 col-sm-8">
                    <div class="product-slider mb-40">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="">
                                    <div id="tabs" class="category-bar mb-20 p-0">
                                        <ul class="tab-stap">
                                            <li><a class="tab-step1 selected" title="step1">Featured Products</a></li>
                                            <li><a class="tab-step2" title="step2">Best Sell Products</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="featured-product">
                            <div class="items">
                                <div class="tab_content pro_cat">
                                    <ul>
                                        <li>
                                            <div id="data-step1" class="items-step1 selected product-slider-main position-r" data-temp="tabdata">

                                                <div class="row mlr_-20">

                                                    <?php $__currentLoopData = $featuredProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div class="col-md-4 col-xs-6 plr-20">

                                                        <div class="product-item <?php echo e($fp->stock == 0 ? 'sold-out' : ''); ?>">

                                                            <?php if($fp->mood_id == 0): ?>
                                                                <div class="sale-label sell-label"><span>Sale</span></div>
                                                            <?php elseif($fp->mood_id == 1): ?>
                                                                <div class="sale-label green-label"><span>New</span></div>
                                                            <?php elseif($fp->mood_id == 2): ?>
                                                                <div class="sale-label red-label"><span>Hot</span></div>
                                                            <?php endif; ?>

                                                            <div class="product-image">
                                                                <a href="<?php echo e(route('product-details',$fp->slug)); ?>"> <img src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($fp->image); ?>" alt="<?php echo e($fp->name); ?>"> </a>
                                                                <div class="product-detail-inner">
                                                                    <div class="detail-inner-left left-side">
                                                                        <ul>
                                                                            <li class="pro-cart-icon">
                                                                                <button title="Add to Cart" class="SingleCartAdd" data-id="<?php echo e($fp->id); ?>"><i class="fa fa-cart"></i></button>
                                                                            </li>
                                                                            <li class="pro-wishlist-icon active"><a class="SingleWishList" data-id="<?php echo e($fp->id); ?>" title="Wishlist"></a></li>
                                                                            <li class="pro-compare-icon"><a id="compareId" data-id="<?php echo e($fp->id); ?>" title="Compare"></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="product-item-details">
                                                                <div class="product-item-name"> <a href="<?php echo e(route('product-details',$fp->slug)); ?>"><?php echo e(substr($fp->name,0,65)); ?></a> </div>
                                                                <div class="price-box">
                                                                    <span class="price"><?php echo e($basic->symbol); ?><?php echo e($fp->current_price); ?></span>
                                                                    <?php if($fp->old_price != null): ?>
                                                                    <del class="price old-price"><?php echo e($basic->symbol); ?><?php echo e($fp->old_price); ?></del>
                                                                    <?php endif; ?>
                                                                    <div class=" right-side">
                                                                        <?php
                                                                            $totalReview = \App\Review::whereProduct_id($fp->id)->count();
                                                                            if ($totalReview == 0){
                                                                                $finalRating = 0;
                                                                            }else{
                                                                                $totalRating = \App\Review::whereProduct_id($fp->id)->sum('rating');
                                                                                $finalRating = round($totalRating / $totalReview);
                                                                            }
                                                                        ?>
                                                                        <div class="rating-result">
                                                                            <span class="product-rating">
                                                                                <?php echo \App\TraitsFolder\CommonTrait::viewRating($finalRating); ?>

                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div id="data-step2" class="items-step2 product-slider-main position-r" data-temp="tabdata" style="display:none">

                                                    <div class="row mlr_-20">

                                                        <?php $__currentLoopData = $bestSell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ffp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $fp = \App\Product::findOrFail($ffp->product_id) ?>

                                                            <div class="col-md-4 col-xs-6 plr-20">

                                                                <div class="product-item <?php echo e($fp->stock == 0 ? 'sold-out' : ''); ?>">
                                                                    <?php if($fp->mood_id == 0): ?>
                                                                        <div class="sale-label sell-label"><span>Sale</span></div>
                                                                    <?php elseif($fp->mood_id == 1): ?>
                                                                        <div class="sale-label green-label"><span>New</span></div>
                                                                    <?php elseif($fp->mood_id == 2): ?>
                                                                        <div class="sale-label red-label"><span>Hot</span></div>
                                                                    <?php endif; ?>
                                                                    <div class="product-image">
                                                                        <a href="<?php echo e(route('product-details',$fp->slug)); ?>"> <img src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($fp->image); ?>" alt="<?php echo e($fp->name); ?>"> </a>
                                                                        <div class="product-detail-inner">
                                                                            <div class="detail-inner-left left-side">
                                                                                <ul>
                                                                                    <li class="pro-cart-icon">
                                                                                        <button title="Add to Cart" class="SingleCartAdd" data-id="<?php echo e($fp->id); ?>"><i class="fa fa-cart"></i></button>
                                                                                    </li>
                                                                                    <li class="pro-wishlist-icon active"><a class="SingleWishList" data-id="<?php echo e($fp->id); ?>" title="Wishlist"></a></li>
                                                                                    <li class="pro-compare-icon"><a id="compareId" data-id="<?php echo e($fp->id); ?>" title="Compare"></a></li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="product-item-details">
                                                                        <div class="product-item-name"> <a href="<?php echo e(route('product-details',$fp->slug)); ?>"><?php echo e(substr($fp->name,0,65)); ?></a> </div>
                                                                        <div class="price-box">
                                                                            <span class="price"><?php echo e($basic->symbol); ?><?php echo e($fp->current_price); ?></span>
                                                                            <?php if($fp->old_price != null): ?>
                                                                                <del class="price old-price"><?php echo e($basic->symbol); ?><?php echo e($fp->old_price); ?></del>
                                                                            <?php endif; ?>
                                                                            <div class=" right-side">
                                                                                <?php
                                                                                    $totalReview = \App\Review::whereProduct_id($fp->id)->count();
                                                                                    if ($totalReview == 0){
                                                                                        $finalRating = 0;
                                                                                    }else{
                                                                                        $totalRating = \App\Review::whereProduct_id($fp->id)->sum('rating');
                                                                                        $finalRating = round($totalRating / $totalReview);
                                                                                    }
                                                                                ?>
                                                                                <div class="rating-result">
                                                                                    <span class="product-rating">
                                                                                        <?php echo \App\TraitsFolder\CommonTrait::viewRating($finalRating); ?>

                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($ad4 != null): ?>
                        <div class="visible-sm visible-md visible-lg hidden-xs">
                            <?php if($ad4->advert_type == 1): ?>
                                <a href="<?php echo e($ad4->link); ?>"  target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad4->val1); ?>" alt="<?php echo e($ad4->title); ?>"></a>
                            <?php else: ?>
                                <?php echo $ad4->val2; ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="ptb-50 ptb-xs-30 gray-bg">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">
                    <div class="product-slider mb-40">
                        <div class="sidebar-title">
                            <h3>Latest Product</h3>
                        </div>
                        <div class="featured-product">


                                <div class="row mlr_-20">

                                    <?php $__currentLoopData = $latestProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-md-3 col-xs-6 plr-20">

                                            <div class="product-item <?php echo e($fp->stock == 0 ? 'sold-out' : ''); ?>">
                                                <?php if($fp->mood_id == 0): ?>
                                                    <div class="sale-label sell-label"><span>Sale</span></div>
                                                <?php elseif($fp->mood_id == 1): ?>
                                                    <div class="sale-label green-label"><span>New</span></div>
                                                <?php elseif($fp->mood_id == 2): ?>
                                                    <div class="sale-label red-label"><span>Hot</span></div>
                                                <?php endif; ?>
                                                <div class="product-image">
                                                    <a href="<?php echo e(route('product-details',$fp->slug)); ?>"> <img src="<?php echo e(asset('assets/images/product')); ?>/<?php echo e($fp->image); ?>" alt="<?php echo e($fp->name); ?>"> </a>
                                                    <div class="product-detail-inner">
                                                        <div class="detail-inner-left left-side">
                                                            <ul>
                                                                <li class="pro-cart-icon">
                                                                    <button title="Add to Cart" class="SingleCartAdd" data-id="<?php echo e($fp->id); ?>"><i class="fa fa-cart"></i></button>
                                                                </li>
                                                                <li class="pro-wishlist-icon active"><a class="SingleWishList" data-id="<?php echo e($fp->id); ?>" title="Wishlist"></a></li>
                                                                <li class="pro-compare-icon"><a id="compareId" data-id="<?php echo e($fp->id); ?>" title="Compare"></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-item-details">
                                                    <div class="product-item-name"> <a href="<?php echo e(route('product-details',$fp->slug)); ?>"><?php echo e(substr($fp->name,0,65)); ?></a> </div>
                                                    <div class="price-box">
                                                        <span class="price"><?php echo e($basic->symbol); ?><?php echo e($fp->current_price); ?></span>
                                                        <?php if($fp->old_price != null): ?>
                                                            <del class="price old-price"><?php echo e($basic->symbol); ?><?php echo e($fp->old_price); ?></del>
                                                        <?php endif; ?>
                                                        <div class=" right-side">
                                                            <?php
                                                                $totalReview = \App\Review::whereProduct_id($fp->id)->count();
                                                                if ($totalReview == 0){
                                                                    $finalRating = 0;
                                                                }else{
                                                                    $totalRating = \App\Review::whereProduct_id($fp->id)->sum('rating');
                                                                    $finalRating = round($totalRating / $totalReview);
                                                                }
                                                            ?>
                                                            <div class="rating-result">
                                                                <span class="product-rating">
                                                                    <?php echo \App\TraitsFolder\CommonTrait::viewRating($finalRating); ?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="pagination-bar">
                                            <?php echo $latestProduct->links('home.pagination'); ?>

                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <?php if($ad4 != null): ?>
                        <div class="visible-sm visible-md visible-lg hidden-xs">
                            <?php if($ad4->advert_type == 1): ?>
                                <a href="<?php echo e($ad4->link); ?>" target="_blank"><img class="center-block" src="<?php echo e(asset('assets/images/advertise')); ?>/<?php echo e($ad4->val1); ?>" alt="<?php echo e($ad4->title); ?>"></a>
                            <?php else: ?>
                                <?php echo $ad4->val2; ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTAINER END -->

    <section class="ptb-50 ptb-xs-30">
        <div class="container">
            <div class="row testimonial">
                <div id="testimonial_slider" class="text-center">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="testimonial_header">
                                    <div>
                                        <img src="<?php echo e(asset('assets/images/testimonial')); ?>/<?php echo e($t->image); ?>" style="width: 95px" class="center-block img-circle">
                                    </div>
                                    <h5><?php echo e($t->name); ?></h5>
                                    <p><?php echo e($t->position); ?></p>
                                </div>
                                <p><?php echo e($t->message); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function() {

            $( "#slider-range" ).slider({
                range: true,
                min: 0,
                max: 1000,
                values: [ 180, 800 ],
                slide: function( event, ui ) {
                    $( "#amount" ).val("<?php echo e($basic->symbol); ?>"+ui.values[ 0 ]+"-<?php echo e($basic->symbol); ?>" + ui.values[ 1 ]);
                }
            });
            $( "#amount" ).val("<?php echo e($basic->symbol); ?>"+$( "#slider-range" ).slider("values",0)+ "-<?php echo e($basic->symbol); ?>"+$( "#slider-range" ).slider( "values", 1));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>